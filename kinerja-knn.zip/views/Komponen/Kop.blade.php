<div class="col-12" style="zoom:87%">
    <div class="row tes2 justify-content-center  align-items-center pb-4 mb-3 mt-3" style="">

        <div class="col-12 d-flex align-items-end justify-content-between text-center" style="position: relative;">
            <div class="" style="margin-left: 10%;margin-top: -1%;;">
                <img src="https://panel.koperasi-ppt.com/upload/koperasi.png" class="img-circle" height="150">
            </div>
            <div>
                <p class="m-0 p-0 kop"><b class="text-black font-weight-bolder"
                        style="font-size: 30pt;color: black;font-family: Times New Roman, Times, serif;text-transform: uppercase;">
                        KOPERASI JASA




                    </b>
                </p>
                <p class="m-0 p-0 kop"><b class="text-black font-weight-bolder"
                        style="font-size: 30pt;color: black;font-family: Times New Roman, Times, serif;text-transform: uppercase;">
                        PEKERJA PUTRI TUJUH
                    </b>
                </p>


            </div>
            <div class="" style="margin-right: 10%;margin-top: -1%;;">
                <img src="https://panel.koperasi-ppt.com/upload/logo2.png" class="img-circle" height="150">
            </div>

        </div>
        <div class="col-12 d-flex align-items-end  justify-content-center text-center py-2 my-2"
            style="position: relative;border-top: solid black 3px;border-bottom: solid black 3px;">
            <p class="m-0 p-0 kop"><b class="text-black font-weight-bolder"
                    style="font-size: 12pt;color: black;font-family: Times New Roman, Times, serif;">
                    ALAMAT : JL. CILACAP BUKIT DATUK – DUMAI 28825, Telp. 443369, 443398 Facs. 0765-31532 <br>Website:
                    <a href="https://koperasi-ppt.com/">https://koperasi-ppt.com/</a> | Email: kop-ppt@yahoo.com
                </b>
            </p>
        </div>

    </div>
</div>
