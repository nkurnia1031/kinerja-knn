<?php use app\Fungsi as Fungsi;?>
<div class="row mt-2 justify-content-between " id="ttdNYa" style="font-size:11pt">
    <div class="col-4">

    </div>
    <div class="col-4">
        <table align="center" style="">
            <tr>
                <td class=" text-nowrap"> <b style="color:black;"> Dumai, {{date('d')}}  {{Fungsi::$bulan[date('n')]}}  {{date('Y')}}</b></td>
            </tr>
            <tr>
                <td class=" text-nowrap"> <b style="color:black;">  {{$data['ttd']->ket}}</td>
            </tr>
            <tr>
                <td class="">
                    <p style="color:black" class="m-0 p-0 ">
                         <b style="color:black;">
                        {{$data['ttd']->jabatan}}
                    </b>

                    </p>
                </td>
            </tr>
              <tr>
                <td class="">
                    <p style="color:black" class="m-0 p-0 ">

                    </p>
                </td>
            </tr>
            <tr>
                <td class="text-center">
                </td>
            </tr>
            <tr>
                <td>
                    <br>
                    <br>
                    <br>
                </td>
            </tr>
            <tr>
                <td style="color: black;">
                    <p class="m-0 p-0">
                        <b>
                        <u> {{empty( $data['ttd'])?"": $data['ttd']->nama}} </u><br>
                         {{empty( $data['ttd'])?"": $data['ttd']->tambahan}}
                         </b>
                    </p>
                    <p class="m-0 p-0 text-center">
                    </p>
                    <p class="m-0 p-0 text-center">
                    </p>
                </td>
            </tr>
        </table>
    </div>
</div>
