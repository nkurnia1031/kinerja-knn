@php
    use app\Fungsi;
@endphp
@extends('Layout.html')
@section('js')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const { createApp } = Vue

        app = createApp({
            data() {
                const periodeList = @json($data['periodeList'] ?? []);
                const activePeriode = periodeList.find(p => p.status === 'aktif')?.id || '';
                return {
                    canManage: '{{ $Session["admin"]->role ?? "" }}' === 'admin',
                    // Base configuration
                    baseURL: 'AnalisaKinerja',
                    
                    // Parameter KNN
                    knnParams: {
                        k: 3,
                        metode_jarak: 'euclidean',
                        normalisasi: 'min_max',
                        nama_analisa: '',
                        periode_id: activePeriode
                    },
                    
                    // Data
                    kriteria: [],
                    dataTraining: [],
                    hasilKlasifikasi: [],
                    riwayatPenilaian: [],
                    statistik: {
                        total_sangat_baik: 0,
                        total_baik: 0,
                        total_cukup: 0,
                        total_kurang: 0
                    },
                    
                    // Daftar analisa sebelumnya
                    daftarAnalisa: [],
                    
                    // State
                    selectedKaryawan: null,
                    selectedAnalisaId: null,
                    showDetail: false,
                    activeTab: 'overview',
                    isLoading: false,
                    isLoadingDetail: false,
                    isUpdatingTraining: false,
                    error: null,
                    periodeList: periodeList,
                    
                    // Charts
                    distributionChart: null,
                    radarChart: null,
                    
                    // Detail perhitungan
                    detailPerhitungan: null
                }
            },
            computed: {
                totalBobot() {
                    return this.kriteria.reduce((sum, k) => sum + parseFloat(k.bobot || 0), 0);
                },
                totalDataTesting() {
                    return this.hasilKlasifikasi.length;
                },
                totalDataTraining() {
                    return this.dataTraining.length;
                }
            },
            mounted() {
                this.loadDaftarAnalisa();
                this.previewAnalisaReal();
                this.loadRiwayatPenilaian();
            },
            methods: {
                // ========================
                // API CALLS
                // ========================
                
                /**
                 * Preview analisa dengan data real tanpa menyimpan
                 */
                async previewAnalisaReal() {
                    this.isLoading = true;
                    this.error = null;
                    
                    try {
                        const response = await axiosInstance.post('AnalisaKinerja-Api?action=preview', {
                            nilai_k: this.knnParams.k,
                            metode_jarak: this.knnParams.metode_jarak,
                            normalisasi: this.knnParams.normalisasi,
                            periode_id: this.knnParams.periode_id || ''
                        });
                        
                        if (response.data.status) {
                            const data = response.data.data;
                            this.kriteria = data.kriteria || [];
                            this.dataTraining = (data.data_training || []).map(t => ({
                                ...t,
                                nilai_kriteria: t.nilai_kriteria || t.nilai || []
                            }));
                            this.hasilKlasifikasi = data.hasil || [];
                            this.statistik = data.statistik;
                            
                            this.$nextTick(() => {
                                this.renderDistributionChart();
                            });
                            
                            new Toast({
                                message: 'Preview analisa dari data aktual berhasil dimuat',
                                type: 'success'
                            });
                        } else {
                            this.error = response.data.message;
                            new Toast({
                                message: response.data.message,
                                type: 'danger'
                            });
                        }
                    } catch (err) {
                        this.error = 'Gagal memproses analisa: ' + (err.response?.data?.message || err.message);
                        new Toast({
                            message: this.error,
                            type: 'danger'
                        });
                    } finally {
                        this.isLoading = false;
                    }
                },
                async prosesAnalisaMock() {
                    return this.previewAnalisaReal();
                },
                
                /**
                 * Proses analisa baru dan simpan ke database
                 */
                async prosesAnalisaBaru() {
                    if (!this.knnParams.nama_analisa) {
                        this.knnParams.nama_analisa = 'Analisa KNN ' + new Date().toLocaleString('id-ID');
                    }
                    
                    this.isLoading = true;
                    this.error = null;
                    
                    try {
                        const response = await axiosInstance.post('AnalisaKinerja-Api?action=proses', {
                            nama_analisa: this.knnParams.nama_analisa,
                            nilai_k: this.knnParams.k,
                            metode_jarak: this.knnParams.metode_jarak,
                            normalisasi: this.knnParams.normalisasi,
                            periode_id: this.knnParams.periode_id || '',
                            simpan_detail: true
                        });
                        
                        if (response.data.status) {
                            const data = response.data.data;
                            this.hasilKlasifikasi = data.hasil;
                            this.statistik = data.statistik;
                            this.selectedAnalisaId = data.analisa_id;
                            
                            this.$nextTick(() => {
                                this.renderDistributionChart();
                            });
                            
                            this.loadDaftarAnalisa();
                            this.loadRiwayatPenilaian();
                            
                            new Toast({
                                message: 'Analisa berhasil disimpan dengan kode: ' + data.kode_analisa,
                                type: 'success'
                            });
                        } else {
                            this.error = response.data.message;
                            new Toast({
                                message: response.data.message,
                                type: 'danger'
                            });
                        }
                    } catch (err) {
                        this.error = 'Gagal menyimpan analisa: ' + (err.response?.data?.message || err.message);
                        new Toast({
                            message: this.error,
                            type: 'danger'
                        });
                    } finally {
                        this.isLoading = false;
                    }
                },
                
                /**
                 * Load daftar analisa sebelumnya
                 */
                async loadDaftarAnalisa() {
                    try {
                        const response = await axiosInstance.get('AnalisaKinerja-Api?action=daftar&limit=20');
                        
                        if (response.data.status) {
                            this.daftarAnalisa = response.data.data.data || [];
                        }
                    } catch (err) {
                        console.error('Gagal load daftar analisa:', err);
                    }
                },
                async loadRiwayatPenilaian() {
                    try {
                        const response = await axiosInstance.get(`AnalisaKinerja-Api?action=riwayat-penilaian&periode_id=${this.knnParams.periode_id || ''}`);
                        if (response.data.status) {
                            this.riwayatPenilaian = response.data.data.data || [];
                        }
                    } catch (err) {
                        console.error('Gagal load riwayat penilaian:', err);
                    }
                },
                async addToTraining(item) {
                    const klasifikasi = item.klasifikasi || '';
                    if (!klasifikasi) {
                        new Toast({ message: 'Klasifikasi penilaian belum tersedia', type: 'danger' });
                        return;
                    }
                    this.isUpdatingTraining = true;
                    try {
                        const response = await axiosInstance.post('KlasifikasiKinerja-Api?action=add-to-training', {
                            penilaian_id: item.id,
                            klasifikasi: klasifikasi
                        });
                        if (response.data.status) {
                            await this.previewAnalisaReal();
                            await this.loadRiwayatPenilaian();
                            new Toast({ message: response.data.message, type: 'success' });
                        } else {
                            new Toast({ message: response.data.message, type: 'danger' });
                        }
                    } catch (err) {
                        new Toast({ message: 'Gagal menambahkan data training', type: 'danger' });
                    } finally {
                        this.isUpdatingTraining = false;
                    }
                },
                async removeFromTraining(item) {
                    this.isUpdatingTraining = true;
                    try {
                        const response = await axiosInstance.post('KlasifikasiKinerja-Api?action=remove-from-training', {
                            penilaian_id: item.id
                        });
                        if (response.data.status) {
                            await this.previewAnalisaReal();
                            await this.loadRiwayatPenilaian();
                            new Toast({ message: response.data.message, type: 'success' });
                        } else {
                            new Toast({ message: response.data.message, type: 'danger' });
                        }
                    } catch (err) {
                        new Toast({ message: 'Gagal menghapus data training', type: 'danger' });
                    } finally {
                        this.isUpdatingTraining = false;
                    }
                },
                
                /**
                 * Load hasil analisa sebelumnya dari database
                 */
                async loadHasilAnalisa(analisaId) {
                    this.isLoading = true;
                    this.error = null;
                    this.selectedAnalisaId = analisaId;
                    
                    try {
                        const response = await axiosInstance.get(`AnalisaKinerja-Api?action=hasil&id=${analisaId}`);
                        
                        if (response.data.status) {
                            const data = response.data.data;
                            
                            this.kriteria = data.kriteria;
                            this.dataTraining = data.data_training;
                            
                            this.hasilKlasifikasi = data.hasil_klasifikasi || [];
                            
                            // Set params from analisa
                            this.knnParams.k = data.analisa.nilai_k;
                            this.knnParams.metode_jarak = data.analisa.metode_jarak;
                            this.knnParams.normalisasi = data.analisa.normalisasi;
                            this.knnParams.nama_analisa = data.analisa.nama_analisa;
                            
                            this.statistik = {
                                total_sangat_baik: data.analisa.total_sangat_baik || 0,
                                total_baik: data.analisa.total_baik || 0,
                                total_cukup: data.analisa.total_cukup || 0,
                                total_kurang: data.analisa.total_kurang || 0
                            };
                            
                            this.$nextTick(() => {
                                this.renderDistributionChart();
                            });
                            
                            new Toast({
                                message: 'Berhasil memuat analisa: ' + data.analisa.kode_analisa,
                                type: 'success'
                            });
                        } else {
                            this.error = response.data.message;
                            new Toast({
                                message: response.data.message,
                                type: 'danger'
                            });
                        }
                    } catch (err) {
                        this.error = 'Gagal memuat analisa: ' + (err.response?.data?.message || err.message);
                        new Toast({
                            message: this.error,
                            type: 'danger'
                        });
                    } finally {
                        this.isLoading = false;
                    }
                },
                
                /**
                 * Lihat detail perhitungan untuk satu karyawan
                 */
                async lihatDetail(hasil) {
                    this.selectedKaryawan = hasil;
                    this.showDetail = true;
                    this.detailPerhitungan = null;
                    
                    // Load detail dari file JSON terpilih
                    if (hasil.db_id) {
                        this.isLoadingDetail = true;
                        try {
                            const response = await axiosInstance.get(`AnalisaKinerja-Api?action=detail&id=${hasil.db_id}`);
                            
                            if (response.data.status) {
                                this.detailPerhitungan = response.data.data;
                            }
                        } catch (err) {
                            console.error('Gagal load detail:', err);
                        } finally {
                            this.isLoadingDetail = false;
                        }
                    }
                    
                    this.$nextTick(() => {
                        this.renderRadarChart();
                        $('#modalDetail').modal('show');
                    });
                },
                
                /**
                 * Hapus analisa
                 */
                async hapusAnalisa(analisaId) {
                    if (!confirm('Apakah Anda yakin ingin menghapus analisa ini?')) {
                        return;
                    }
                    
                    try {
                        const response = await axiosInstance.delete(`AnalisaKinerja-Api?action=hapus&id=${analisaId}`);
                        
                        if (response.data.status) {
                            this.loadDaftarAnalisa();
                            new Toast({
                                message: 'Analisa berhasil dihapus',
                                type: 'success'
                            });
                        } else {
                            new Toast({
                                message: response.data.message,
                                type: 'danger'
                            });
                        }
                    } catch (err) {
                        new Toast({
                            message: 'Gagal menghapus analisa',
                            type: 'danger'
                        });
                    }
                },
                
                // ========================
                // UI METHODS
                // ========================
                
                setActiveTab(tab) {
                    this.activeTab = tab;
                    if (tab === 'overview') {
                        this.$nextTick(() => this.renderDistributionChart());
                    }
                },
                
                tutupDetail() {
                    this.showDetail = false;
                    this.selectedKaryawan = null;
                    this.detailPerhitungan = null;
                    $('#modalDetail').modal('hide');
                },
                
                ubahParameterK() {
                    // Re-process dengan parameter baru
                    this.previewAnalisaReal();
                },
                
                // ========================
                // CHART METHODS
                // ========================
                
                renderDistributionChart() {
                    if (this.distributionChart) this.distributionChart.destroy();
                    
                    const ctx = document.getElementById('distributionChart');
                    if (ctx) {
                        this.distributionChart = new Chart(ctx, {
                            type: 'doughnut',
                            data: {
                                labels: ['Sangat Baik', 'Baik', 'Cukup', 'Kurang'],
                                datasets: [{
                                    data: [
                                        this.statistik.total_sangat_baik,
                                        this.statistik.total_baik,
                                        this.statistik.total_cukup,
                                        this.statistik.total_kurang
                                    ],
                                    backgroundColor: ['#1cc88a', '#4e73df', '#f6c23e', '#e74a3b']
                                }]
                            },
                            options: {
                                responsive: true,
                                plugins: {
                                    legend: { position: 'bottom' }
                                }
                            }
                        });
                    }
                },
                
                renderRadarChart() {
                    if (this.radarChart) this.radarChart.destroy();
                    
                    const ctx = document.getElementById('radarDetailChart');
                    if (ctx && this.selectedKaryawan) {
                        const labels = this.kriteria.map(k => k.kode);
                        const nilai = this.selectedKaryawan.karyawan.nilai;
                        
                        this.radarChart = new Chart(ctx, {
                            type: 'radar',
                            data: {
                                labels: labels,
                                datasets: [{
                                    label: this.selectedKaryawan.karyawan.nama,
                                    data: nilai,
                                    backgroundColor: 'rgba(78, 115, 223, 0.2)',
                                    borderColor: '#4e73df',
                                    pointBackgroundColor: '#4e73df'
                                }]
                            },
                            options: {
                                responsive: true,
                                scales: {
                                    r: {
                                        beginAtZero: true,
                                        max: 4,
                                        ticks: { stepSize: 1 }
                                    }
                                }
                            }
                        });
                    }
                },
                
                // ========================
                // HELPER METHODS
                // ========================
                
                getKlasifikasiClass(klasifikasi) {
                    const mapping = {
                        'Sangat Baik': 'success',
                        'Baik': 'primary',
                        'Cukup': 'warning',
                        'Kurang': 'danger'
                    };
                    return mapping[klasifikasi] || 'secondary';
                },
                
                getNilaiClass(nilai) {
                    if (nilai >= 4) return 'success';
                    if (nilai >= 3) return 'primary';
                    if (nilai >= 2) return 'warning';
                    return 'danger';
                },
                
                formatDistance(d) {
                    return typeof d === 'number' ? d.toFixed(4) : d;
                },
                
                hitungRataRata(nilai) {
                    if (!nilai || nilai.length === 0) return '0.00';
                    return (nilai.reduce((a, b) => a + b, 0) / nilai.length).toFixed(2);
                },
                
                formatTanggal(tanggal) {
                    if (!tanggal) return '-';
                    return new Date(tanggal).toLocaleDateString('id-ID', {
                        day: '2-digit',
                        month: 'short',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                    });
                },
                
                getStatusClass(status) {
                    const mapping = {
                        'selesai': 'success',
                        'proses': 'warning',
                        'gagal': 'danger'
                    };
                    return mapping[status] || 'secondary';
                },
                
                exportJSON() {
                    const dataExport = {
                        parameter: this.knnParams,
                        kriteria: this.kriteria,
                        data_training: this.dataTraining,
                        statistik: this.statistik,
                        hasil_klasifikasi: this.hasilKlasifikasi,
                        exported_at: new Date().toISOString()
                    };
                    
                    const dataStr = JSON.stringify(dataExport, null, 2);
                    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
                    const linkElement = document.createElement('a');
                    linkElement.setAttribute('href', dataUri);
                    linkElement.setAttribute('download', 'knn_analysis_data.json');
                    linkElement.click();
                }
            }
        }).mount('#app')
    </script>
@endsection
@section('css')
    <style>
        .chart-container {
            position: relative;
            height: 280px;
        }
        .methodology-card {
            border-left: 4px solid #4e73df;
        }
        .formula-box {
            background: #f8f9fc;
            border: 1px solid #e3e6f0;
            border-radius: 8px;
            padding: 20px;
            font-family: 'Courier New', monospace;
        }
        .formula-box .formula {
            font-size: 1.1rem;
            color: #2c3e50;
            text-align: center;
            margin: 15px 0;
        }
        .step-number {
            width: 32px;
            height: 32px;
            background: #4e73df;
            color: white;
            border-radius: 50%;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            margin-right: 10px;
        }
        .distance-table td, .distance-table th {
            vertical-align: middle;
            font-size: 0.85rem;
        }
        .k-nearest-highlight {
            background-color: #d4edda !important;
        }
        .nav-tabs .nav-link.active {
            background-color: #4e73df;
            color: white;
            border-color: #4e73df;
        }
        .nav-tabs .nav-link {
            color: #4e73df;
        }
        .criteria-badge {
            font-size: 0.75rem;
            padding: 4px 8px;
        }
        .analisa-card {
            cursor: pointer;
            transition: all 0.2s ease;
        }
        .analisa-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
        }
        .analisa-card.active {
            border-color: #4e73df !important;
            border-width: 2px;
        }
        .loading-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255,255,255,0.8);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10;
        }
        .param-control {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .param-control input, .param-control select {
            width: auto;
        }
    </style>
@endsection
@section('modal')
    {{-- Modal Detail KNN Calculation --}}
    
@endsection
@section('isi')
    <div class="row" id="app">
        {{-- Header --}}
        <div class="modal fade" id="modalDetail" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-xl" role="document">
                <div class="modal-content">
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title" v-if="selectedKaryawan">
                            <i class="fas fa-calculator mr-2"></i>
                            Detail Perhitungan KNN - @{{ selectedKaryawan.karyawan.nama }}
                        </h5>
                        <button type="button" class="close text-white" data-dismiss="modal">
                            <span>&times;</span>
                        </button>
                    </div>
                    <div class="modal-body" v-if="selectedKaryawan">
                        {{-- Loading indicator --}}
                        <div v-if="isLoadingDetail" class="text-center py-4">
                            <div class="spinner-border text-primary" role="status">
                                <span class="sr-only">Loading...</span>
                            </div>
                            <p class="mt-2">Memuat detail perhitungan...</p>
                        </div>
                        
                        <div v-else class="row">
                            {{-- Info Karyawan --}}
                            <div class="col-md-4 mb-3">
                                <div class="card h-100">
                                    <div class="card-header bg-light">
                                        <strong>Data Karyawan</strong>
                                    </div>
                                    <div class="card-body">
                                        <table class="table table-sm table-borderless">
                                            <tr>
                                                <td>Nomor Pekerja</td>
                                                <td>: @{{ selectedKaryawan.karyawan.nomor_pekerja || selectedKaryawan.karyawan.nip || '-' }}</td>
                                            </tr>
                                            <tr>
                                                <td>Nama</td>
                                                <td>: @{{ selectedKaryawan.karyawan.nama }}</td>
                                            </tr>
                                            <tr>
                                                <td>Jabatan</td>
                                                <td>: @{{ selectedKaryawan.karyawan.jabatan || '-' }}</td>
                                            </tr>
                                            <tr>
                                                <td>Pekerjaan</td>
                                                <td>: @{{ selectedKaryawan.karyawan.pekerjaan || '-' }}</td>
                                            </tr>
                                        </table>
                                        <hr>
                                        <h6 class="font-weight-bold">Hasil Klasifikasi:</h6>
                                        <span class="badge badge-lg" :class="'badge-' + getKlasifikasiClass(selectedKaryawan.hasil_klasifikasi)">
                                            @{{ selectedKaryawan.hasil_klasifikasi }}
                                        </span>
                                        <br><br>
                                        <small class="text-muted">
                                            Confidence: <strong>@{{ selectedKaryawan.confidence }}%</strong>
                                        </small>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Radar Chart --}}
                            <div class="col-md-8 mb-3">
                                <div class="card h-100">
                                    <div class="card-header bg-light">
                                        <strong>Visualisasi Nilai per Kriteria</strong>
                                    </div>
                                    <div class="card-body">
                                        <canvas id="radarDetailChart" height="200"></canvas>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Nilai per Kriteria --}}
                            <div class="col-12 mb-3">
                                <div class="card">
                                    <div class="card-header bg-light">
                                        <strong>Nilai per Kriteria</strong>
                                    </div>
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-sm">
                                                <thead class="bg-primary text-white">
                                                    <tr>
                                                        <th>Kode</th>
                                                        <th>Kriteria</th>
                                                        <th class="text-center">Bobot</th>
                                                        <th class="text-center">Nilai (1-4)</th>
                                                        <th class="text-center">Nilai x Bobot</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <tr v-for="(k, idx) in kriteria" :key="k.id">
                                                        <td><span class="badge badge-secondary">@{{ k.kode }}</span></td>
                                                        <td>
                                                            @{{ k.nama }}
                                                            <br><small class="text-muted">@{{ k.nama_en }}</small>
                                                        </td>
                                                        <td class="text-center">@{{ k.bobot }}%</td>
                                                        <td class="text-center">
                                                            <span class="badge" :class="'badge-' + getNilaiClass(selectedKaryawan.karyawan.nilai[idx])">
                                                                @{{ selectedKaryawan.karyawan.nilai[idx] }}
                                                            </span>
                                                        </td>
                                                        <td class="text-center">
                                                            @{{ (selectedKaryawan.karyawan.nilai[idx] * k.bobot / 100).toFixed(3) }}
                                                        </td>
                                                    </tr>
                                                </tbody>
                                                <tfoot class="bg-light font-weight-bold">
                                                    <tr>
                                                        <td colspan="2">Total</td>
                                                        <td class="text-center">@{{ totalBobot }}%</td>
                                                        <td class="text-center">@{{ hitungRataRata(selectedKaryawan.karyawan.nilai) }}</td>
                                                        <td class="text-center">-</td>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- Tabel Jarak ke Semua Data Training --}}
                            <div class="col-12 mb-3" v-if="selectedKaryawan.all_distances || detailPerhitungan">
                                <div class="card">
                                    <div class="card-header bg-light">
                                        <strong><i class="fas fa-ruler mr-2"></i>Perhitungan Jarak Euclidean ke Semua Data Training</strong>
                                    </div>
                                    <div class="card-body">
                                        <div class="alert alert-info">
                                            <strong>Rumus Euclidean Distance (dengan bobot):</strong><br>
                                            <code>d(x,y) = sqrt( SUM[ (xi - yi)^2 * (wi/100)^2 ] )</code><br>
                                            <small>Dimana: xi = nilai karyawan, yi = nilai data training, wi = bobot kriteria</small>
                                        </div>
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-sm distance-table">
                                                <thead class="bg-secondary text-white">
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Nama (Training)</th>
                                                        <th>Klasifikasi</th>
                                                        <th class="text-center">Jarak</th>
                                                        <th class="text-center">Ranking</th>
                                                    </tr>
                                                </thead>
                                                <tbody v-if="detailPerhitungan && detailPerhitungan.detail_jarak">
                                                    <tr v-for="(d, idx) in detailPerhitungan.detail_jarak" 
                                                        :key="d.id"
                                                        :class="d.is_k_nearest ? 'k-nearest-highlight' : ''">
                                                        <td>@{{ d.training_id }}</td>
                                                        <td>
                                                            @{{ d.nama_training }}
                                                            <span v-if="d.is_k_nearest" class="badge badge-success ml-2">K-Nearest</span>
                                                        </td>
                                                        <td>
                                                            <span class="badge" :class="'badge-' + getKlasifikasiClass(d.klasifikasi_training)">
                                                                @{{ d.klasifikasi_training }}
                                                            </span>
                                                        </td>
                                                        <td class="text-center font-weight-bold">@{{ formatDistance(d.nilai_jarak) }}</td>
                                                        <td class="text-center">@{{ d.ranking }}</td>
                                                    </tr>
                                                </tbody>
                                                <tbody v-else-if="selectedKaryawan.all_distances">
                                                    <tr v-for="(d, idx) in selectedKaryawan.all_distances" 
                                                        :key="d.training_id"
                                                        :class="d.is_k_nearest ? 'k-nearest-highlight' : ''">
                                                        <td>@{{ d.training_id }}</td>
                                                        <td>
                                                            @{{ d.nama }}
                                                            <span v-if="d.is_k_nearest" class="badge badge-success ml-2">K-Nearest</span>
                                                        </td>
                                                        <td>
                                                            <span class="badge" :class="'badge-' + getKlasifikasiClass(d.klasifikasi)">
                                                                @{{ d.klasifikasi }}
                                                            </span>
                                                        </td>
                                                        <td class="text-center font-weight-bold">@{{ formatDistance(d.jarak) }}</td>
                                                        <td class="text-center">@{{ d.ranking }}</td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            {{-- K-Nearest Neighbors & Voting --}}
                            <div class="col-md-6 mb-3">
                                <div class="card h-100 border-success">
                                    <div class="card-header bg-success text-white">
                                        <strong><i class="fas fa-users mr-2"></i>@{{ knnParams.k }} Tetangga Terdekat</strong>
                                    </div>
                                    <div class="card-body">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Nama</th>
                                                    <th>Jarak</th>
                                                    <th>Klasifikasi</th>
                                                </tr>
                                            </thead>
                                            <tbody v-if="detailPerhitungan && detailPerhitungan.k_nearest">
                                                <tr v-for="(n, idx) in detailPerhitungan.k_nearest" :key="n.id">
                                                    <td>@{{ idx + 1 }}</td>
                                                    <td>@{{ n.nama_training }}</td>
                                                    <td>@{{ formatDistance(n.nilai_jarak) }}</td>
                                                    <td>
                                                        <span class="badge" :class="'badge-' + getKlasifikasiClass(n.klasifikasi_training)">
                                                            @{{ n.klasifikasi_training }}
                                                        </span>
                                                    </td>
                                                </tr>
                                            </tbody>
                                            <tbody v-else-if="selectedKaryawan.k_nearest">
                                                <tr v-for="(n, idx) in selectedKaryawan.k_nearest" :key="n.training_id">
                                                    <td>@{{ idx + 1 }}</td>
                                                    <td>@{{ n.nama }}</td>
                                                    <td>@{{ formatDistance(n.jarak) }}</td>
                                                    <td>
                                                        <span class="badge" :class="'badge-' + getKlasifikasiClass(n.klasifikasi)">
                                                            @{{ n.klasifikasi }}
                                                        </span>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-md-6 mb-3">
                                <div class="card h-100 border-primary">
                                    <div class="card-header bg-primary text-white">
                                        <strong><i class="fas fa-vote-yea mr-2"></i>Hasil Voting</strong>
                                    </div>
                                    <div class="card-body">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Klasifikasi</th>
                                                    <th class="text-center">Jumlah Vote</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr v-for="(count, kelas) in selectedKaryawan.voting" :key="kelas"
                                                    :class="kelas === selectedKaryawan.hasil_klasifikasi ? 'table-success' : ''">
                                                    <td>
                                                        <span class="badge" :class="'badge-' + getKlasifikasiClass(kelas)">
                                                            @{{ kelas }}
                                                        </span>
                                                        <span v-if="kelas === selectedKaryawan.hasil_klasifikasi" class="ml-2">
                                                            <i class="fas fa-check-circle text-success"></i> Terpilih
                                                        </span>
                                                    </td>
                                                    <td class="text-center font-weight-bold">@{{ count }}</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                        <hr>
                                        <div class="alert alert-success mb-0">
                                            <strong>Kesimpulan:</strong><br>
                                            Berdasarkan voting dari @{{ knnParams.k }} tetangga terdekat, 
                                            karyawan <strong>@{{ selectedKaryawan.karyawan.nama }}</strong> 
                                            diklasifikasikan sebagai 
                                            <span class="badge" :class="'badge-' + getKlasifikasiClass(selectedKaryawan.hasil_klasifikasi)">
                                                @{{ selectedKaryawan.hasil_klasifikasi }}
                                            </span>
                                            dengan tingkat kepercayaan <strong>@{{ selectedKaryawan.confidence }}%</strong>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                        <button type="button" class="btn btn-primary" onclick="window.print()">
                            <i class="fas fa-print"></i> Cetak
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-12 mb-3">
            <div class="card bg-gradient-primary text-white shadow">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h4 class="mb-1">
                                <i class="fas fa-brain mr-2"></i>
                                Analisa Klasifikasi Kinerja - Metode K-Nearest Neighbor (KNN)
                            </h4>
                            <p class="mb-0 opacity-75">
                                Sistem klasifikasi kinerja karyawan menggunakan algoritma KNN dengan perhitungan di server
                            </p>
                        </div>
                        <div class="col-md-4 text-md-right mt-3 mt-md-0">
                            <button class="btn btn-light btn-sm mr-2" @click="exportJSON" :disabled="isLoading">
                                <i class="fas fa-download"></i> Export JSON
                            </button>
                            <a href="AnalisaKinerja-Cetak" target="_blank" class="btn btn-light btn-sm">
                                <i class="fas fa-print"></i> Cetak Laporan
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Parameter KNN Control --}}
        <div class="col-12 mb-3">
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-cogs mr-2"></i>Parameter KNN
                    </h6>
                </div>
                <div class="card-body">
                    <div class="row align-items-end">
                        <div class="col-md-2 mb-2">
                            <label class="small font-weight-bold">Nilai K</label>
                            <select v-model.number="knnParams.k" class="form-control form-control-sm">
                                <option v-for="n in 10" :key="n" :value="n">K = @{{ n }}</option>
                            </select>
                        </div>
                        <div class="col-md-2 mb-2">
                            <label class="small font-weight-bold">Metode Jarak</label>
                            <select v-model="knnParams.metode_jarak" class="form-control form-control-sm">
                                <option value="euclidean">Euclidean</option>
                                <option value="manhattan">Manhattan</option>
                            </select>
                        </div>
                        <div class="col-md-3 mb-2">
                            <label class="small font-weight-bold">Periode Penilaian</label>
                            <select v-model="knnParams.periode_id" class="form-control form-control-sm">
                                <option value="">Periode Aktif</option>
                                <option v-for="periode in periodeList" :key="periode.id" :value="periode.id">
                                    @{{ periode.nama_periode }} (@{{ periode.status }})
                                </option>
                            </select>
                        </div>
                        <div class="col-md-3 mb-2">
                            <label class="small font-weight-bold">Nama Analisa (opsional)</label>
                            <input type="text" v-model="knnParams.nama_analisa" class="form-control form-control-sm" 
                                placeholder="Nama analisa...">
                        </div>
                        <div class="col-md-2 mb-2">
                            <button class="btn btn-primary btn-sm mr-2" @click="previewAnalisaReal" :disabled="isLoading">
                                <i class="fas fa-play"></i> Preview
                            </button>
                            <button v-if="canManage" class="btn btn-success btn-sm mr-2" @click="prosesAnalisaBaru" :disabled="isLoading">
                                <i class="fas fa-save"></i> Proses & Simpan
                            </button>
                            <button class="btn btn-secondary btn-sm" @click="loadDaftarAnalisa" :disabled="isLoading">
                                <i class="fas fa-sync"></i> Refresh
                            </button>
                        </div>
                    </div>
                    <div class="alert alert-info mt-3 mb-0">
                        <small>
                            Data training KNN diambil dari seluruh riwayat penilaian yang ditandai training, tetapi selalu
                            <strong>mengabaikan periode yang sedang diklasifikasi</strong>. Data testing diambil dari
                            <strong>semua penilaian pada periode aktif / periode yang dipilih</strong>.
                        </small>
                    </div>
                </div>
            </div>
        </div>

        {{-- Daftar Analisa Sebelumnya --}}
        <div class="col-12 mb-3" v-if="daftarAnalisa.length > 0">
            <div class="card shadow">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-history mr-2"></i>Riwayat Analisa
                    </h6>
                    <span class="badge badge-info">@{{ daftarAnalisa.length }} analisa</span>
                </div>
                <div class="card-body" style="max-height: 200px; overflow-y: auto;">
                    <div class="row">
                        <div class="col-md-3 col-sm-6 mb-2" v-for="analisa in daftarAnalisa" :key="analisa.id">
                            <div class="card analisa-card border-left-primary h-100" 
                                :class="{ active: selectedAnalisaId === analisa.id }"
                                @click="loadHasilAnalisa(analisa.id)">
                                <div class="card-body p-2">
                                    <small class="text-muted d-block">@{{ analisa.kode_analisa }}</small>
                                    <strong class="d-block text-truncate" style="font-size: 0.8rem;">
                                        @{{ analisa.nama_analisa }}
                                    </strong>
                                    <div class="d-flex justify-content-between align-items-center mt-1">
                                        <span class="badge" :class="'badge-' + getStatusClass(analisa.status)">
                                            @{{ analisa.status }}
                                        </span>
                                        <small class="text-muted">K=@{{ analisa.nilai_k }}</small>
                                    </div>
                                    <small class="text-muted d-block mt-1">
                                        @{{ formatTanggal(analisa.created_at) }}
                                    </small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Navigation Tabs --}}
        <div class="col-12 mb-3">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a class="nav-link" :class="{ active: activeTab === 'overview' }" 
                       href="#" @click.prevent="setActiveTab('overview')">
                        <i class="fas fa-chart-pie mr-1"></i> Overview
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" :class="{ active: activeTab === 'methodology' }" 
                       href="#" @click.prevent="setActiveTab('methodology')">
                        <i class="fas fa-book mr-1"></i> Metodologi KNN
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" :class="{ active: activeTab === 'kriteria' }" 
                       href="#" @click.prevent="setActiveTab('kriteria')">
                        <i class="fas fa-list mr-1"></i> Kriteria Penilaian
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" :class="{ active: activeTab === 'training' }" 
                       href="#" @click.prevent="setActiveTab('training')">
                        <i class="fas fa-database mr-1"></i> Data Training
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" :class="{ active: activeTab === 'hasil' }" 
                       href="#" @click.prevent="setActiveTab('hasil')">
                        <i class="fas fa-poll mr-1"></i> Hasil Klasifikasi
                    </a>
                </li>
            </ul>
        </div>

        {{-- Loading Indicator --}}
        <div class="col-12 text-center py-5" v-if="isLoading">
            <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;">
                <span class="sr-only">Loading...</span>
            </div>
            <p class="mt-3 text-muted">Memproses analisa KNN...</p>
        </div>

        {{-- Error Alert --}}
        <div class="col-12 mb-3" v-if="error && !isLoading">
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle mr-2"></i>
                @{{ error }}
            </div>
        </div>

        {{-- Tab Content: Overview --}}
        <div class="col-12" v-show="activeTab === 'overview' && !isLoading">
            <div class="row" v-if="statistik">
                {{-- Stats Cards --}}
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-success shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Sangat Baik</div>
                                    <div  class="h5 mb-0 font-weight-bold text-gray-800">@{{ statistik.total_sangat_baik }} Karyawan</div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-star fa-2x text-success"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-primary shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Baik</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">@{{ statistik.total_baik }} Karyawan</div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-thumbs-up fa-2x text-primary"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-warning shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Cukup</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">@{{ statistik.total_cukup }} Karyawan</div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-minus-circle fa-2x text-warning"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-6 mb-4">
                    <div class="card border-left-danger shadow h-100 py-2">
                        <div class="card-body">
                            <div class="row no-gutters align-items-center">
                                <div class="col mr-2">
                                    <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Kurang</div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">@{{ statistik.total_kurang }} Karyawan</div>
                                </div>
                                <div class="col-auto">
                                    <i class="fas fa-exclamation-triangle fa-2x text-danger"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                {{-- Distribution Chart --}}
                <div class="col-lg-5 mb-4">
                    <div class="card shadow h-100">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">
                                <i class="fas fa-chart-pie mr-2"></i>Distribusi Klasifikasi Kinerja
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="chart-container">
                                <canvas id="distributionChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>

                {{-- Parameter Info --}}
                <div class="col-lg-7 mb-4">
                    <div class="card shadow h-100">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">
                                <i class="fas fa-info-circle mr-2"></i>Informasi Analisa
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <table class="table table-sm table-borderless">
                                        <tr>
                                            <td class="font-weight-bold">Nilai K</td>
                                            <td>: @{{ knnParams.k }}</td>
                                        </tr>
                                        <tr>
                                            <td class="font-weight-bold">Metode Jarak</td>
                                            <td>: @{{ knnParams.metode_jarak }}</td>
                                        </tr>
                                        <tr>
                                            <td class="font-weight-bold">Normalisasi</td>
                                            <td>: @{{ knnParams.normalisasi }}</td>
                                        </tr>
                                    </table>
                                </div>
                                <div class="col-md-6">
                                    <table class="table table-sm table-borderless">
                                        <tr>
                                            <td class="font-weight-bold">Data Training</td>
                                            <td>: @{{ totalDataTraining }} data</td>
                                        </tr>
                                        <tr>
                                            <td class="font-weight-bold">Data Testing</td>
                                            <td>: @{{ totalDataTesting }} data</td>
                                        </tr>
                                        <tr>
                                            <td class="font-weight-bold">Kriteria</td>
                                            <td>: @{{ kriteria.length }} kriteria</td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                            <hr>
                            <div class="alert alert-info mb-0">
                                <small>
                                    <strong>Catatan:</strong> Analisa ini menggunakan algoritma K-Nearest Neighbor (KNN) 
                                    untuk mengklasifikasikan kinerja karyawan berdasarkan @{{ kriteria.length }} kriteria penilaian.
                                    Semua perhitungan dilakukan di server untuk memastikan akurasi dan konsistensi data.
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Tab Content: Methodology --}}
        <div class="col-12" v-show="activeTab === 'methodology' && !isLoading">
            <div class="row" v-if="statistik">
                <div class="col-lg-6 mb-4">
                    <div class="card shadow methodology-card">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">
                                <i class="fas fa-cogs mr-2"></i>Apa itu K-Nearest Neighbor (KNN)?
                            </h6>
                        </div>
                        <div class="card-body">
                            <p>
                                K-Nearest Neighbor (KNN) adalah algoritma klasifikasi yang mengelompokkan data baru 
                                berdasarkan <strong>K tetangga terdekat</strong> dari data training yang sudah ada.
                            </p>
                            <h6 class="font-weight-bold mt-4">Langkah-langkah KNN:</h6>
                            <ol class="mb-0">
                                <li class="mb-2">
                                    <span class="step-number">1</span>
                                    Tentukan nilai K (jumlah tetangga)
                                </li>
                                <li class="mb-2">
                                    <span class="step-number">2</span>
                                    Hitung jarak data baru ke semua data training
                                </li>
                                <li class="mb-2">
                                    <span class="step-number">3</span>
                                    Urutkan berdasarkan jarak terdekat
                                </li>
                                <li class="mb-2">
                                    <span class="step-number">4</span>
                                    Ambil K tetangga terdekat
                                </li>
                                <li class="mb-2">
                                    <span class="step-number">5</span>
                                    Lakukan voting mayoritas
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 mb-4">
                    <div class="card shadow methodology-card">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">
                                <i class="fas fa-calculator mr-2"></i>Rumus Perhitungan Jarak
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="formula-box">
                                <h6 class="font-weight-bold text-center">Euclidean Distance (dengan bobot)</h6>
                                <div class="formula">
                                    d(x, y) = sqrt( SUM[ (xi - yi)^2 * (wi/W)^2 ] )
                                </div>
                                <hr>
                                <small>
                                    <strong>Keterangan:</strong><br>
                                    <ul class="mb-0">
                                        <li>d(x, y) = Jarak antara data x dan y</li>
                                        <li>xi = Nilai kriteria ke-i data testing</li>
                                        <li>yi = Nilai kriteria ke-i data training</li>
                                        <li>wi = Bobot kriteria ke-i</li>
                                        <li>W = Total bobot semua kriteria</li>
                                    </ul>
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Tab Content: Kriteria --}}
        <div class="col-12" v-show="activeTab === 'kriteria' && !isLoading">
            <div class="card shadow mb-4" v-if="kriteria">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-list mr-2"></i>Kriteria Penilaian Kinerja (@{{ kriteria.length }} Kriteria)
                    </h6>
                    <span class="badge" :class="totalBobot == 100 ? 'badge-success' : 'badge-warning'">
                        Total Bobot: @{{ totalBobot }}%
                    </span>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="bg-primary text-white">
                                <tr>
                                    <th class="text-center" width="60">Kode</th>
                                    <th>Kriteria (Bahasa Indonesia)</th>
                                    <th>Kriteria (English)</th>
                                    <th class="text-center" width="100">Bobot</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="k in kriteria" :key="k.id">
                                    <td class="text-center">
                                        <span class="badge badge-secondary">@{{ k.kode }}</span>
                                    </td>
                                    <td>@{{ k.nama }}</td>
                                    <td class="text-muted">@{{ k.nama_en }}</td>
                                    <td class="text-center">
                                        <span class="badge badge-info">@{{ k.bobot }}%</span>
                                    </td>
                                </tr>
                            </tbody>
                            <tfoot class="bg-light font-weight-bold">
                                <tr>
                                    <td colspan="3" class="text-right">Total Bobot:</td>
                                    <td class="text-center">
                                        <span class="badge" :class="totalBobot == 100 ? 'badge-success' : 'badge-danger'">
                                            @{{ totalBobot }}%
                                        </span>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    <h6 class="font-weight-bold mt-4">Skala Penilaian:</h6>
                    <div class="row">
                        <div class="col-md-3 mb-2">
                            <div class="card bg-danger text-white">
                                <div class="card-body text-center py-2">
                                    <h4 class="mb-0">1</h4>
                                    <small>Kurang Baik</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-2">
                            <div class="card bg-warning">
                                <div class="card-body text-center py-2">
                                    <h4 class="mb-0">2</h4>
                                    <small>Cukup</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-2">
                            <div class="card bg-primary text-white">
                                <div class="card-body text-center py-2">
                                    <h4 class="mb-0">3</h4>
                                    <small>Baik</small>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3 mb-2">
                            <div class="card bg-success text-white">
                                <div class="card-body text-center py-2">
                                    <h4 class="mb-0">4</h4>
                                    <small>Sangat Baik</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Tab Content: Data Training --}}
        <div class="col-12" v-show="activeTab === 'training' && !isLoading">
            <div class="card shadow mb-4" v-if="dataTraining">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-database mr-2"></i>Data Training (@{{ dataTraining.length }} Data)
                    </h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="bg-secondary text-white">
                                <tr>
                                    <th class="text-center" width="50">ID</th>
                                    <th>Nama</th>
                                    <th>Periode</th>
                                    <th class="text-center">Nilai per Kriteria</th>
                                    <th class="text-center" width="80">Rata-rata</th>
                                    <th class="text-center" width="120">Klasifikasi</th>
                                    <th class="text-center" width="120">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="t in dataTraining" :key="t.id">
                                    <td class="text-center">@{{ t.id || t.karyawan_id }}</td>
                                    <td>@{{ t.nama || t.nama_karyawan }}</td>
                                    <td>@{{ t.nama_periode || '-' }}</td>
                                    <td class="text-center">
                                        <span v-for="(n, idx) in (t.nilai_kriteria || [])" :key="idx" 
                                            class="badge mr-1" :class="'badge-' + getNilaiClass(n)">
                                            @{{ n }}
                                        </span>
                                    </td>
                                    <td class="text-center font-weight-bold">
                                        @{{ hitungRataRata(t.nilai_kriteria || []) }}
                                    </td>
                                    <td class="text-center">
                                        <span class="badge" :class="'badge-' + getKlasifikasiClass(t.klasifikasi || t.klasifikasi_label)">
                                            @{{ t.klasifikasi || t.klasifikasi_label }}
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <button v-if="canManage" class="btn btn-sm btn-outline-danger" @click="removeFromTraining(t)" :disabled="isUpdatingTraining">
                                            <i class="fas fa-minus-circle"></i> Hapus
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <hr>
                    <h6 class="font-weight-bold text-primary mb-3">
                        <i class="fas fa-history mr-2"></i>Riwayat Penilaian untuk Data Training
                    </h6>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="bg-light">
                                <tr>
                                    <th class="text-center" width="50">ID</th>
                                    <th>Nama</th>
                                    <th>Periode</th>
                                    <th class="text-center" width="90">Nilai</th>
                                    <th class="text-center" width="120">Klasifikasi Penilaian</th>
                                    <th class="text-center" width="120">Klasifikasi KNN</th>
                                    <th>Penilai</th>
                                    <th class="text-center" width="120">Status Training</th>
                                    <th class="text-center" width="120">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="item in riwayatPenilaian" :key="'riwayat-' + item.id">
                                    <td class="text-center">@{{ item.id }}</td>
                                    <td>@{{ item.nama }}</td>
                                    <td>@{{ item.nama_periode || '-' }}</td>
                                    <td class="text-center">@{{ item.total_nilai || '-' }}</td>
                                    <td class="text-center">
                                        <span class="badge" :class="'badge-' + getKlasifikasiClass(item.klasifikasi)">
                                            @{{ item.klasifikasi || '-' }}
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge" :class="'badge-' + getKlasifikasiClass(item.klasifikasi_knn)">
                                            @{{ item.klasifikasi_knn || '-' }}
                                        </span>
                                    </td>
                                    <td>@{{ item.nama_penilai || '-' }}</td>
                                    <td class="text-center">
                                        <span class="badge" :class="item.is_training ? 'badge-success' : 'badge-secondary'">
                                            @{{ item.is_training ? 'Training' : 'Non-Training' }}
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <button v-if="canManage && !item.is_training" class="btn btn-sm btn-outline-primary" @click="addToTraining(item)" :disabled="isUpdatingTraining || !item.klasifikasi">
                                            <i class="fas fa-plus-circle"></i> Tambah
                                        </button>
                                        <button v-else-if="canManage" class="btn btn-sm btn-outline-danger" @click="removeFromTraining(item)" :disabled="isUpdatingTraining">
                                            <i class="fas fa-minus-circle"></i> Hapus
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        {{-- Tab Content: Hasil Klasifikasi --}}
        <div class="col-12" v-show="activeTab === 'hasil' && !isLoading">
            <div class="card shadow mb-4" v-if="hasilKlasifikasi">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-poll mr-2"></i>Hasil Klasifikasi KNN (@{{ hasilKlasifikasi.length }} Karyawan)
                    </h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="bg-primary text-white">
                                <tr>
                                    <th class="text-center" width="50">No</th>
                                    <th>Nama Karyawan</th>
                                    <th>Jabatan</th>
                                    <th>Pekerjaan</th>
                                    <th class="text-center" width="80">Rata-rata</th>
                                    <th class="text-center" width="120">Klasifikasi Penilaian</th>
                                    <th class="text-center" width="120">Klasifikasi KNN</th>
                                    <th class="text-center" width="80">Confidence</th>
                                    <th class="text-center" width="80">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(h, index) in hasilKlasifikasi" :key="h.karyawan.id || index">
                                    <td class="text-center">@{{ index + 1 }}</td>
                                    <td class="font-weight-bold">@{{ h.karyawan.nama }}</td>
                                    <td>@{{ h.karyawan.jabatan || '-' }}</td>
                                    <td>@{{ h.karyawan.pekerjaan || '-' }}</td>
                                    <td class="text-center">@{{ h.rata_rata_nilai || hitungRataRata(h.karyawan.nilai) }}</td>
                                    <td class="text-center">
                                        <span class="badge" :class="'badge-' + getKlasifikasiClass(h.karyawan.klasifikasi_penilaian)">
                                            @{{ h.karyawan.klasifikasi_penilaian || '-' }}
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge" :class="'badge-' + getKlasifikasiClass(h.hasil_klasifikasi)">
                                            @{{ h.hasil_klasifikasi }}
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge badge-light">@{{ h.confidence }}%</span>
                                    </td>
                                    <td class="text-center">
                                        <button class="btn btn-sm btn-info" @click="lihatDetail(h)" title="Lihat Detail">
                                            <i class="fas fa-search"></i>
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
