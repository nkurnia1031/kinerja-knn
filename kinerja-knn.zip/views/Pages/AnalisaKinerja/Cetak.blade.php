@php
    use app\Fungsi;
@endphp
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Analisa Klasifikasi Kinerja - Metode KNN</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            font-size: 11pt;
            line-height: 1.5;
            color: #333;
            padding: 20px;
        }
        .header {
            text-align: center;
            border-bottom: 3px double #333;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }
        .header h1 {
            font-size: 16pt;
            margin-bottom: 5px;
        }
        .header h2 {
            font-size: 14pt;
            font-weight: normal;
            color: #555;
        }
        .header p {
            font-size: 10pt;
            color: #666;
        }
        .section {
            margin-bottom: 25px;
            page-break-inside: avoid;
        }
        .section-title {
            background: #4e73df;
            color: white;
            padding: 8px 15px;
            font-size: 12pt;
            font-weight: bold;
            margin-bottom: 10px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 6px 8px;
            text-align: left;
            font-size: 9pt;
        }
        th {
            background: #f8f9fa;
            font-weight: bold;
        }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .badge {
            display: inline-block;
            padding: 2px 8px;
            border-radius: 3px;
            font-size: 8pt;
            font-weight: bold;
        }
        .badge-success { background: #1cc88a; color: white; }
        .badge-primary { background: #4e73df; color: white; }
        .badge-warning { background: #f6c23e; color: #333; }
        .badge-danger { background: #e74a3b; color: white; }
        .formula-box {
            background: #f8f9fc;
            border: 1px solid #e3e6f0;
            padding: 15px;
            margin: 10px 0;
            font-family: 'Courier New', monospace;
        }
        .formula-box .formula {
            text-align: center;
            font-size: 12pt;
            margin: 10px 0;
        }
        .info-box {
            background: #e8f4fd;
            border-left: 4px solid #4e73df;
            padding: 10px 15px;
            margin: 10px 0;
        }
        .stats-grid {
            display: flex;
            gap: 15px;
            margin: 15px 0;
        }
        .stat-card {
            flex: 1;
            border: 1px solid #ddd;
            padding: 15px;
            text-align: center;
        }
        .stat-card .value {
            font-size: 24pt;
            font-weight: bold;
        }
        .stat-card .label {
            font-size: 10pt;
            color: #666;
        }
        .page-break {
            page-break-before: always;
        }
        .footer {
            margin-top: 30px;
            padding-top: 15px;
            border-top: 1px solid #ddd;
            font-size: 9pt;
            color: #666;
        }
        .signature-section {
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
        }
        .signature-box {
            width: 200px;
            text-align: center;
        }
        .signature-line {
            border-bottom: 1px solid #333;
            margin: 60px 0 5px;
        }
        @media print {
            body { padding: 0; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <button onclick="window.print()" class="no-print" style="position: fixed; top: 10px; right: 10px; padding: 10px 20px; background: #4e73df; color: white; border: none; cursor: pointer;">
        Cetak Laporan
    </button>

    {{-- Header --}}
    <div class="header">
        <h1>LAPORAN ANALISA KLASIFIKASI KINERJA KARYAWAN</h1>
        <h2>Metode K-Nearest Neighbor (KNN)</h2>
        <p>Periode: {{ $periode ?? 'Tahun 2024' }} | Tanggal Cetak: {{ date('d F Y') }}</p>
    </div>

    {{-- Section: Ringkasan --}}
    <div class="section">
        <div class="section-title">1. RINGKASAN EKSEKUTIF</div>
        <div class="stats-grid">
            <div class="stat-card">
                <div class="value" style="color: #1cc88a;">{{ $sangat_baik ?? 1 }}</div>
                <div class="label">Sangat Baik</div>
            </div>
            <div class="stat-card">
                <div class="value" style="color: #4e73df;">{{ $baik ?? 1 }}</div>
                <div class="label">Baik</div>
            </div>
            <div class="stat-card">
                <div class="value" style="color: #f6c23e;">{{ $cukup ?? 2 }}</div>
                <div class="label">Cukup</div>
            </div>
            <div class="stat-card">
                <div class="value" style="color: #e74a3b;">{{ $kurang ?? 1 }}</div>
                <div class="label">Kurang</div>
            </div>
        </div>
        <div class="info-box">
            <strong>Kesimpulan:</strong> Berdasarkan analisis menggunakan algoritma KNN dengan K=3, 
            dari total {{ $total ?? 5 }} karyawan yang dinilai, mayoritas berada pada klasifikasi 
            yang memadai dengan distribusi yang merata.
        </div>
    </div>

    {{-- Section: Metodologi --}}
    <div class="section">
        <div class="section-title">2. METODOLOGI K-NEAREST NEIGHBOR (KNN)</div>
        <p><strong>Parameter yang digunakan:</strong></p>
        <table>
            <tr>
                <th style="width: 200px;">Parameter</th>
                <th>Nilai</th>
                <th>Keterangan</th>
            </tr>
            <tr>
                <td>Nilai K</td>
                <td><strong>3</strong></td>
                <td>Jumlah tetangga terdekat yang digunakan untuk voting</td>
            </tr>
            <tr>
                <td>Metode Jarak</td>
                <td><strong>Euclidean Distance</strong></td>
                <td>Jarak Euclidean dengan pembobotan kriteria</td>
            </tr>
            <tr>
                <td>Normalisasi</td>
                <td><strong>Min-Max Scaling</strong></td>
                <td>Skala nilai 1-4</td>
            </tr>
        </table>

        <div class="formula-box">
            <p><strong>Rumus Euclidean Distance (Weighted):</strong></p>
            <div class="formula">
                d(x, y) = √Σ<sub>i=1</sub><sup>n</sup> (x<sub>i</sub> - y<sub>i</sub>)² × (w<sub>i</sub>/100)²
            </div>
            <p style="font-size: 9pt;">
                Dimana: x<sub>i</sub> = nilai kriteria data testing, y<sub>i</sub> = nilai kriteria data training, 
                w<sub>i</sub> = bobot kriteria ke-i, n = jumlah kriteria
            </p>
        </div>
    </div>

    {{-- Section: Kriteria --}}
    <div class="section">
        <div class="section-title">3. KRITERIA PENILAIAN (13 KRITERIA)</div>
        <table>
            <thead>
                <tr>
                    <th class="text-center" style="width: 60px;">Kode</th>
                    <th>Kriteria (Bahasa Indonesia)</th>
                    <th>Kriteria (English)</th>
                    <th class="text-center" style="width: 80px;">Bobot</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="text-center">K01</td>
                    <td>Pemahaman terhadap Tanggung Jawab</td>
                    <td>Understanding of Job Responsibility</td>
                    <td class="text-center">10%</td>
                </tr>
                <tr>
                    <td class="text-center">K02</td>
                    <td>Pengetahuan terhadap Prosedur Pekerjaan</td>
                    <td>Knowledge of Task Procedure</td>
                    <td class="text-center">8%</td>
                </tr>
                <tr>
                    <td class="text-center">K03</td>
                    <td>Inisiatif</td>
                    <td>Initiative</td>
                    <td class="text-center">7%</td>
                </tr>
                <tr>
                    <td class="text-center">K04</td>
                    <td>Kemampuan Belajar terhadap Sistem Baru</td>
                    <td>Learning Ability</td>
                    <td class="text-center">7%</td>
                </tr>
                <tr>
                    <td class="text-center">K05</td>
                    <td>Kemampuan dalam Kerjasama Tim</td>
                    <td>Teamwork</td>
                    <td class="text-center">8%</td>
                </tr>
                <tr>
                    <td class="text-center">K06</td>
                    <td>Motivasi dalam Bekerja</td>
                    <td>Motivation</td>
                    <td class="text-center">7%</td>
                </tr>
                <tr>
                    <td class="text-center">K07</td>
                    <td>Tanggung Jawab</td>
                    <td>Responsibility</td>
                    <td class="text-center">9%</td>
                </tr>
                <tr>
                    <td class="text-center">K08</td>
                    <td>Loyalitas</td>
                    <td>Loyalty</td>
                    <td class="text-center">7%</td>
                </tr>
                <tr>
                    <td class="text-center">K09</td>
                    <td>Komunikasi</td>
                    <td>Communication</td>
                    <td class="text-center">8%</td>
                </tr>
                <tr>
                    <td class="text-center">K10</td>
                    <td>Kedisiplinan</td>
                    <td>Discipline</td>
                    <td class="text-center">8%</td>
                </tr>
                <tr>
                    <td class="text-center">K11</td>
                    <td>Kehadiran</td>
                    <td>Attendance</td>
                    <td class="text-center">8%</td>
                </tr>
                <tr>
                    <td class="text-center">K12</td>
                    <td>Perilaku</td>
                    <td>Attitude - Mentality</td>
                    <td class="text-center">6%</td>
                </tr>
                <tr>
                    <td class="text-center">K13</td>
                    <td>Aspek HSSE</td>
                    <td>HSSE Aspect</td>
                    <td class="text-center">7%</td>
                </tr>
            </tbody>
            <tfoot>
                <tr style="background: #e8f4fd;">
                    <td colspan="3" class="text-right"><strong>Total Bobot:</strong></td>
                    <td class="text-center"><strong>100%</strong></td>
                </tr>
            </tfoot>
        </table>

        <p><strong>Skala Penilaian:</strong></p>
        <table>
            <tr>
                <th class="text-center" style="width: 80px;">Nilai</th>
                <th style="width: 120px;">Label</th>
                <th>Deskripsi</th>
            </tr>
            <tr>
                <td class="text-center"><span class="badge badge-danger">1</span></td>
                <td>Kurang Baik</td>
                <td>Performa di bawah standar, perlu perbaikan signifikan</td>
            </tr>
            <tr>
                <td class="text-center"><span class="badge badge-warning">2</span></td>
                <td>Cukup</td>
                <td>Performa memenuhi standar minimum</td>
            </tr>
            <tr>
                <td class="text-center"><span class="badge badge-primary">3</span></td>
                <td>Baik</td>
                <td>Performa di atas standar</td>
            </tr>
            <tr>
                <td class="text-center"><span class="badge badge-success">4</span></td>
                <td>Baik Sekali</td>
                <td>Performa sangat memuaskan, melebihi ekspektasi</td>
            </tr>
        </table>
    </div>

    <div class="page-break"></div>

    {{-- Section: Hasil Klasifikasi --}}
    <div class="section">
        <div class="section-title">4. HASIL KLASIFIKASI KNN</div>
        <table>
            <thead>
                <tr>
                    <th class="text-center">No</th>
                    <th>NIP</th>
                    <th>Nama Karyawan</th>
                    <th>Jabatan</th>
                    <th>Departemen</th>
                    <th class="text-center">Rata-rata</th>
                    <th class="text-center">Klasifikasi</th>
                    <th class="text-center">Confidence</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="text-center">1</td>
                    <td>EMP-2023-001</td>
                    <td>Kartika Sari</td>
                    <td>Staff IT</td>
                    <td>IT</td>
                    <td class="text-center">3.38</td>
                    <td class="text-center"><span class="badge badge-primary">Baik</span></td>
                    <td class="text-center">66.7%</td>
                </tr>
                <tr>
                    <td class="text-center">2</td>
                    <td>EMP-2023-002</td>
                    <td>Lukman Hakim</td>
                    <td>Staff HRD</td>
                    <td>HRD</td>
                    <td class="text-center">2.23</td>
                    <td class="text-center"><span class="badge badge-warning">Cukup</span></td>
                    <td class="text-center">100.0%</td>
                </tr>
                <tr>
                    <td class="text-center">3</td>
                    <td>EMP-2023-003</td>
                    <td>Maya Putri</td>
                    <td>Staff Finance</td>
                    <td>Finance</td>
                    <td class="text-center">3.85</td>
                    <td class="text-center"><span class="badge badge-success">Sangat Baik</span></td>
                    <td class="text-center">100.0%</td>
                </tr>
                <tr>
                    <td class="text-center">4</td>
                    <td>EMP-2023-004</td>
                    <td>Nanda Pratiwi</td>
                    <td>Staff Marketing</td>
                    <td>Marketing</td>
                    <td class="text-center">1.62</td>
                    <td class="text-center"><span class="badge badge-danger">Kurang</span></td>
                    <td class="text-center">66.7%</td>
                </tr>
                <tr>
                    <td class="text-center">5</td>
                    <td>EMP-2023-005</td>
                    <td>Oscar Putra</td>
                    <td>Staff Produksi</td>
                    <td>Produksi</td>
                    <td class="text-center">3.00</td>
                    <td class="text-center"><span class="badge badge-primary">Baik</span></td>
                    <td class="text-center">100.0%</td>
                </tr>
            </tbody>
        </table>
    </div>

    {{-- Section: Contoh Perhitungan Detail --}}
    <div class="section">
        <div class="section-title">5. CONTOH PERHITUNGAN DETAIL (Kartika Sari)</div>
        
        <p><strong>Data Karyawan:</strong> Kartika Sari (EMP-2023-001) - Staff IT</p>
        <p><strong>Nilai per Kriteria:</strong> [3, 4, 3, 4, 3, 3, 4, 3, 3, 4, 3, 3, 4]</p>
        
        <p style="margin-top: 15px;"><strong>Langkah 1: Hitung Jarak ke Semua Data Training</strong></p>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama (Training)</th>
                    <th>Klasifikasi</th>
                    <th class="text-center">Jarak Euclidean</th>
                    <th class="text-center">Ranking</th>
                </tr>
            </thead>
            <tbody>
                <tr style="background: #d4edda;">
                    <td>T3</td>
                    <td>Citra Dewi</td>
                    <td>Baik</td>
                    <td class="text-center"><strong>0.0866</strong></td>
                    <td class="text-center">1</td>
                </tr>
                <tr style="background: #d4edda;">
                    <td>T4</td>
                    <td>Deni Firmansyah</td>
                    <td>Baik</td>
                    <td class="text-center"><strong>0.1225</strong></td>
                    <td class="text-center">2</td>
                </tr>
                <tr style="background: #d4edda;">
                    <td>T10</td>
                    <td>Joko Widodo</td>
                    <td>Baik</td>
                    <td class="text-center"><strong>0.1323</strong></td>
                    <td class="text-center">3</td>
                </tr>
                <tr>
                    <td>T1</td>
                    <td>Ahmad Supardi</td>
                    <td>Sangat Baik</td>
                    <td class="text-center">0.1414</td>
                    <td class="text-center">4</td>
                </tr>
                <tr>
                    <td>T2</td>
                    <td>Budi Santoso</td>
                    <td>Sangat Baik</td>
                    <td class="text-center">0.1500</td>
                    <td class="text-center">5</td>
                </tr>
                <tr>
                    <td colspan="5" class="text-center">... (data lainnya)</td>
                </tr>
            </tbody>
        </table>
        <p style="font-size: 9pt; color: #666;">* Baris hijau menunjukkan 3 tetangga terdekat (K-Nearest)</p>

        <p style="margin-top: 15px;"><strong>Langkah 2: Voting dari K=3 Tetangga Terdekat</strong></p>
        <table style="width: 400px;">
            <tr>
                <th>Klasifikasi</th>
                <th class="text-center">Jumlah Vote</th>
            </tr>
            <tr style="background: #d4edda;">
                <td>Baik</td>
                <td class="text-center"><strong>3</strong></td>
            </tr>
            <tr>
                <td>Sangat Baik</td>
                <td class="text-center">0</td>
            </tr>
            <tr>
                <td>Cukup</td>
                <td class="text-center">0</td>
            </tr>
            <tr>
                <td>Kurang</td>
                <td class="text-center">0</td>
            </tr>
        </table>

        <div class="info-box" style="margin-top: 15px;">
            <strong>Kesimpulan:</strong> Berdasarkan voting mayoritas, Kartika Sari diklasifikasikan sebagai 
            <span class="badge badge-primary">Baik</span> dengan confidence 100% (3/3 vote).
        </div>
    </div>

    {{-- Signature --}}
    <div class="signature-section">
        <div class="signature-box">
            <p>Mengetahui,</p>
            <p><strong>Manager HRD</strong></p>
            <div class="signature-line"></div>
            <p>(_____________________)</p>
        </div>
        <div class="signature-box">
            <p>Dibuat oleh,</p>
            <p><strong>Admin Sistem</strong></p>
            <div class="signature-line"></div>
            <p>(_____________________)</p>
        </div>
    </div>

    {{-- Footer --}}
    <div class="footer">
        <p>Dokumen ini dicetak secara otomatis oleh Sistem Penilaian Kinerja Karyawan</p>
        <p>Tanggal: {{ date('d/m/Y H:i:s') }}</p>
    </div>
</body>
</html>
