<div class="mt-3 p-3 bg-light rounded">
    <div class="row">
        <div class="col-md-6">
            <h6 class="font-weight-bold mb-2"><i class="fas fa-info-circle mr-2"></i>Keterangan Klasifikasi:</h6>
            @include('Komponen.KlasifikasiBadge', ['text' => 'Sangat Baik'])
            @include('Komponen.KlasifikasiBadge', ['text' => 'Baik'])
            @include('Komponen.KlasifikasiBadge', ['text' => 'Cukup'])
            @include('Komponen.KlasifikasiBadge', ['text' => 'Kurang'])
        </div>
        <div class="col-md-6">
            <h6 class="font-weight-bold mb-2"><i class="fas fa-ruler mr-2"></i>Skala Penilaian:</h6>
            <small>
                <span class="badge badge-danger">1</span> Kurang Baik |
                <span class="badge badge-warning">2</span> Cukup |
                <span class="badge badge-primary">3</span> Baik |
                <span class="badge badge-success">4</span> Baik Sekali
            </small>
        </div>
    </div>
</div>
