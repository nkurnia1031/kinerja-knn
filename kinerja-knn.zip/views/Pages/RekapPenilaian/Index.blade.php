@php
    use app\Fungsi;
@endphp
@extends('Layout.html')
@section('js')
    <script>
        const {
            createApp
        } = Vue

        app = createApp({
            data() {
                data = dataAwal();
                data.baseURL = 'RekapPenilaian';
                data.selectedPeriode = '';
                data.periodeList = [];
                return data;
            },
            computed: computedAwal,
            mounted() {
                this.loadPeriode();
                this.GetData();
            },
            methods: {
                ...methodAwal,
                loadPeriode() {
                    this.apiGet('PeriodePenilaian').then(res => {
                        this.periodeList = res.data.data.data || [];
                    });
                },
                filterByPeriode() {
                    this.request.periode_id = this.selectedPeriode;
                    this.GetData();
                },
                getKlasifikasiClass(klasifikasi) {
                    const mapping = {
                        'Sangat Baik': 'success',
                        'Baik': 'primary',
                        'Cukup': 'warning',
                        'Kurang': 'danger',
                        'Sangat Kurang': 'dark'
                    };
                    return mapping[klasifikasi] || 'secondary';
                },
                lihatDetail(item) {
                    // Navigate to detail view with penilaian ID
                    window.location.href = 'RekapPenilaian-View?id=' + item.id;
                },
                exportExcel() {
                    window.open('RekapPenilaian-XLSX?periode_id=' + this.selectedPeriode, '_blank');
                },
                cetakRekap() {
                    window.open('RekapPenilaian-Cetak?periode_id=' + this.selectedPeriode, '_blank');
                }
            }
        }).mount('#app')
    </script>
@endsection
@section('css')
    <style>
        .slide-fade-enter-active {
            transition: all 0.3s ease-out;
        }

        .slide-fade-leave-active {
            transition: all 0.8s cubic-bezier(1, 0.5, 0.8, 1);
        }

        .slide-fade-enter-from,
        .slide-fade-leave-to {
            transform: translateX(20px);
            opacity: 0;
        }

        .table-bordered td,
        .table-bordered th {
            color: black !important;
            border: 1px solid #000000 !important;
            padding-top: 5px !important;
            padding-bottom: 5px !important;
            padding-left: 8px !important;
            padding-right: 8px !important;
        }
    </style>
@endsection
@section('modal')
@endsection
@section('isi')
    <div class="row" id="app">
        {{-- Header --}}
        <div class="col-12 mb-3">
            <div class="card bg-gradient-info text-white shadow">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h4 class="mb-1">Rekap Penilaian Kinerja</h4>
                            <p class="mb-0 opacity-75">
                                Rekap data karyawan, kriteria, dan hasil penilaian kinerja
                            </p>
                        </div>
                        <div class="col-md-4 text-md-right mt-3 mt-md-0">
                            <i class="fas fa-file-alt fa-4x opacity-50"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Filter --}}
        <div class="col-12 mb-3">
            <div class="card shadow">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-md-4">
                            <label class="font-weight-bold">Filter Periode:</label>
                            <select v-model="selectedPeriode" @change="filterByPeriode" class="form-control">
                                <option value="">-- Semua Periode --</option>
                                <option v-for="p in periodeList" :value="p.id">@{{ p.nama_periode }}</option>
                            </select>
                        </div>
                        <div class="col-md-8 text-right">
                            <a :href="'RekapPenilaian-Cetak?periode_id=' + selectedPeriode" target="_blank" 
                                class="btn btn-dark mr-2">
                                <i class="fas fa-print"></i> Cetak Rekap
                            </a>
                            <a :href="'RekapPenilaian-XLSX?periode_id=' + selectedPeriode" target="_blank" 
                                class="btn btn-success">
                                <i class="fas fa-file-excel"></i> Export Excel
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Tabel Rekap --}}
        <div class="col-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-table"></i> Data Rekap Penilaian
                    </h6>
                    <button @click="GetData()" class="btn btn-sm btn-secondary">
                        <i class="fas fa-sync"></i> Refresh
                    </button>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped">
                            <thead class="bg-light">
                                <tr>
                                    <th>No</th>
                                    <th>Nomor Pekerja</th>
                                    <th>Nama Karyawan</th>
                                    <th>Jabatan</th>
                                    <th>Pekerjaan</th>
                                    <th>Periode</th>
                                    <th>Penilai</th>
                                    <th>Total Nilai</th>
                                    <th>Klasifikasi Penilaian</th>
                                    <th>Klasifikasi KNN</th>
                                    <th>Tanggal</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(item, index) in data2" :key="item.id">
                                    <td class="text-center">@{{ index + 1 }}</td>
                                    <td>@{{ item.nomor_pekerja }}</td>
                                    <td>@{{ item.nama }}</td>
                                    <td>@{{ item.jabatan }}</td>
                                    <td>@{{ item.pekerjaan }}</td>
                                    <td>@{{ item.periode }}</td>
                                    <td>@{{ item.nama_penilai }}</td>
                                    <td class="text-center font-weight-bold">@{{ item.total_nilai }}</td>
                                    <td class="text-center">
                                        <span :class="'badge badge-' + getKlasifikasiClass(item.klasifikasi)">
                                            @{{ item.klasifikasi }}
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <span :class="'badge badge-' + getKlasifikasiClass(item.klasifikasi_knn)">
                                            @{{ item.klasifikasi_knn || '-' }}
                                        </span>
                                    </td>
                                    <td>@{{ item.tanggal_penilaian }}</td>
                                    <td class="text-center">
                                        <button @click="lihatDetail(item)" class="btn btn-sm btn-info" title="Lihat Detail">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div v-if="data2.length == 0" class="text-center py-5">
                        <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">Belum ada data penilaian</h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
