@php
    use app\Fungsi;
@endphp
@extends('Layout.html')
@section('js')
    <script>
        const {
            createApp
        } = Vue

        app = createApp({
            data() {
                data = dataAwal();
                data.baseURL = 'PeriodePenilaian';
                return data;
            },
            computed: computedAwal,
            mounted() {
                this.GetData();
            },
            beforeUpdated() {},
            updated() {},
            methods: {
                ...methodAwal,
                aktivasiPeriode(id) {
                    if (confirm('Apakah Anda yakin ingin mengaktifkan periode ini? Periode lain akan dinonaktifkan.')) {
                        axios.post('api/PeriodePenilaian/aktivasi', { id: id }).then(res => {
                            if (res.data.success) {
                                alert('Periode berhasil diaktifkan!');
                                this.GetData();
                            } else {
                                alert('Gagal mengaktifkan periode: ' + res.data.message);
                            }
                        });
                    }
                }
            }
        }).mount('#app')
    </script>
@endsection
@section('css')
    <style>
        .slide-fade-enter-active {
            transition: all 0.3s ease-out;
        }

        .slide-fade-leave-active {
            transition: all 0.8s cubic-bezier(1, 0.5, 0.8, 1);
        }

        .slide-fade-enter-from,
        .slide-fade-leave-to {
            transform: translateX(20px);
            opacity: 0;
        }

        .table-bordered td,
        .table-bordered th {
            color: black !important;
            border: 1px solid #000000 !important;
            padding-top: 5px !important;
            padding-bottom: 5px !important;
            padding-left: 8px !important;
            padding-right: 8px !important;
        }

        .periode-aktif {
            background-color: #d4edda !important;
        }
    </style>
@endsection
@section('modal')
@endsection
@section('isi')
    <div class="row" id="app">
        {{-- Info Card --}}
        <div class="col-12 mb-3">
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> 
                <strong>Periode Penilaian</strong> - Kelola periode penilaian kinerja tahunan. 
                Hanya satu periode yang dapat aktif pada satu waktu.
            </div>
        </div>

        @component('Pages.Form')
            @slot('tambahan')
                <template v-else-if="inArray(data.name,['status'])">
                    <select class="form-control" :name="'input[' + data.name + ']'" :id="data.name + '1'">
                        <option value="">-- Pilih Status --</option>
                        <option value="aktif" :selected="data.val == 'aktif'">Aktif</option>
                        <option value="nonaktif" :selected="data.val == 'nonaktif'">Non-Aktif</option>
                        <option value="selesai" :selected="data.val == 'selesai'">Selesai</option>
                    </select>
                </template>
                <template v-else-if="inArray(data.name,['tanggal_mulai','tanggal_selesai'])">
                    <input type="date" class="form-control" :name="'input[' + data.name + ']'" 
                        :id="data.name + '1'" :value="data.val">
                </template>
            @endslot
        @endcomponent
        @component('Pages.Filter')
        @endcomponent

        <div class="col-lg-12 col-md-12">
            <div class="card o-hidden border-bottom-dark shadow">
                <div class="card-header align-items-center justify-content-between d-flex py-3">
                    <span>
                        <h6 class="m-0 font-weight-bold text-dark">Data Periode Penilaian</h6>
                    </span>
                    <span class="d-flex flex-wrap justify-content-end">
                        <a @click="setAwal" class="btn mr-1 mb-1 btn-sm btn-primary">
                            <i class="fa fa-plus"></i> Tambah Periode
                        </a>
                        <a href="javascript:;" @click="GetData()" class="btn mr-1 mb-1 btn-sm btn-secondary">
                            <i class="fa fa-sync"></i> Refresh
                        </a>
                    </span>
                </div>
                <div class="table-responsive">
                    <table class="table text-nowrap table-striped w-100">
                        <thead class="text-center">
                            <tr>
                                <th>No.</th>
                                <th>Nama Periode</th>
                                <th>Tanggal Mulai</th>
                                <th>Tanggal Selesai</th>
                                <th>Status</th>
                                <th>Progress</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(i, index) in data2" :key="i.id" :class="{'periode-aktif': i.status == 'aktif'}">
                                <td class="text-center">@{{ index + 1 }}</td>
                                <td>
                                    <strong>@{{ i.nama_periode }}</strong>
                                    <span v-if="i.status == 'aktif'" class="badge badge-success ml-2">AKTIF</span>
                                </td>
                                <td class="text-center">@{{ i.tanggal_mulai }}</td>
                                <td class="text-center">@{{ i.tanggal_selesai }}</td>
                                <td class="text-center">
                                    <span v-if="i.status == 'aktif'" class="badge badge-success">Aktif</span>
                                    <span v-else-if="i.status == 'nonaktif'" class="badge badge-secondary">Non-Aktif</span>
                                    <span v-else class="badge badge-info">Selesai</span>
                                </td>
                                <td class="text-center">
                                    <div class="progress" style="height: 20px; min-width: 100px;">
                                        <div class="progress-bar bg-success" role="progressbar" 
                                            :style="'width: ' + (i.progress || 0) + '%'">
                                            @{{ i.progress || 0 }}%
                                        </div>
                                    </div>
                                    <small class="text-muted">@{{ i.sudah_dinilai || 0 }}/@{{ i.total_karyawan || 0 }}</small>
                                </td>
                                <td class="text-center">
                                    <button v-if="i.status != 'aktif'" @click="aktivasiPeriode(i.id)" 
                                        class="btn btn-sm btn-success mr-1" title="Aktifkan Periode">
                                        <i class="fas fa-check"></i>
                                    </button>
                                    <button @click="EditData(index)" class="btn btn-sm btn-warning mr-1">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <button @click="HapusData(index)" class="btn btn-sm btn-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
