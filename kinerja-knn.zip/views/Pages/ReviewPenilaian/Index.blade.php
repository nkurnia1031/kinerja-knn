@php
    use app\Fungsi;
@endphp
@extends('Layout.html')
@section('js')
    <script>
        const {
            createApp
        } = Vue

        app = createApp({
            data() {
                data = dataAwal();
                data.baseURL = 'ReviewPenilaian';
                data.detailPenilaian = null;
                data.showDetail = false;
                return data;
            },
            computed: computedAwal,
            mounted() {
                this.GetData();
            },
            methods: {
                ...methodAwal,
                lihatDetail(penilaian) {
                    axiosInstance.get(`ReviewPenilaian-Api?id=${penilaian.id}`).then(res => {
                        this.detailPenilaian = res.data.data.data[0];
                        this.showDetail = true;
                    });
                    setTimeout(function() {
                var target = $('#detail');
                if (target.length) {
                    $('html, body').stop().animate({
                        scrollTop: target.offset().top
                    }, 300);
                }
            }, 500);
                   
                },
                tutupDetail() {
                    this.showDetail = false;
                    this.detailPenilaian = null;
                },
                getKlasifikasiClass(klasifikasi) {
                    const mapping = {
                        'Sangat Baik': 'success',
                        'Baik': 'primary',
                        'Cukup': 'warning',
                        'Kurang': 'danger',
                        'Sangat Kurang': 'dark'
                    };
                    return mapping[klasifikasi] || 'secondary';
                },
                cetakPenilaian(id) {
                    window.open('ReviewPenilaian-Cetak?id=' + id, '_blank');
                }
            }
        }).mount('#app')
    </script>
@endsection
@section('css')
    <style>
        .review-card {
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .review-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
        }
    </style>
@endsection
@section('modal')
@endsection
@section('isi')
    <div class="row" id="app">
        {{-- Header --}}
       
        <div class="col-12 mb-3">
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> 
                <strong>Review Penilaian</strong> - Lihat kembali penilaian yang telah Anda berikan kepada bawahan.
            </div>
        </div>

        {{-- Detail Penilaian --}}
        <div v-if="showDetail && detailPenilaian" id="detail" class="col-12 mb-3">
            <div class="card shadow">
                <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold">
                        <i class="fas fa-file-alt"></i> Detail Penilaian - @{{ detailPenilaian.karyawan[0]?.nama  }}
                    </h6>
                    <div>
                        {{-- <button @click="cetakPenilaian(detailPenilaian.id)" class="btn btn-sm btn-light mr-2">
                            <i class="fas fa-print"></i> Cetak
                        </button> --}}
                        <button @click="tutupDetail" class="btn btn-sm btn-light">
                            <i class="fas fa-times"></i> Tutup
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    {{-- Info Karyawan --}}
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h5 class="font-weight-bold">@{{ detailPenilaian.karyawan[0]?.nama }}</h5>
                            <p class="mb-1"><strong>Jabatan:</strong> @{{ detailPenilaian.karyawan[0]?.jabatan }}</p>
                            <p class="mb-1"><strong>Pekerjaan:</strong> @{{ detailPenilaian.karyawan[0]?.pekerjaan }}</p>
                            <p class="mb-1"><strong>Periode:</strong> @{{ detailPenilaian.periode[0].nama_periode }}</p>
                        </div>
                        <div class="col-md-6">
                            <div class="card bg-light">
                                <div class="card-body text-center">
                                    <h6 class="text-muted">Total Nilai</h6>
                                    <h2 :class="'text-' + getKlasifikasiClass(detailPenilaian.klasifikasi)">
                                        @{{ detailPenilaian.total_nilai }}
                                    </h2>
                                    <span :class="'badge badge-' + getKlasifikasiClass(detailPenilaian.klasifikasi)">
                                        @{{ detailPenilaian.klasifikasi }}
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    {{-- Detail Per Kriteria --}}
                    <h6 class="font-weight-bold mb-3">Detail Nilai Per Kriteria</h6>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="bg-light">
                                <tr>
                                    <th>No</th>
                                    <th>Kriteria</th>
                                    <th>Bobot</th>
                                    <th>Nilai</th>
                                    <th>Nilai x Bobot</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(detail, index) in detailPenilaian.detail_kriteria">
                                    <td class="text-center">@{{ index + 1 }}</td>
                                    <td>@{{ detail.nama_kriteria }}</td>
                                    <td class="text-center">@{{ detail.bobot }}%</td>
                                    <td class="text-center">@{{ detail.nilai }}</td>
                                    <td class="text-center">@{{ detail.nilai_bobot }}</td>
                                </tr>
                            </tbody>
                            <tfoot class="bg-light font-weight-bold">
                                <tr>
                                    <td colspan="4" class="text-right">Total:</td>
                                    <td class="text-center">@{{ detailPenilaian.total_nilai }}</td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    {{-- Catatan --}}
                    <div v-if="detailPenilaian.catatan" class="mt-4">
                        <h6 class="font-weight-bold">Catatan Penilaian:</h6>
                        <div class="alert alert-secondary">
                            @{{ detailPenilaian.catatan }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
        @component('Pages.Filter')
        @endcomponent

        {{-- Daftar Penilaian --}}
        <div class="col-12">
            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">
                        <i class="fas fa-list"></i> Daftar Penilaian yang Telah Diberikan
                    </h6>
                    <button @click="GetData()" class="btn btn-sm btn-secondary">
                        <i class="fas fa-sync"></i> Refresh
                    </button>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead class="bg-light">
                                <tr>
                                    <th>No</th>
                                    <th>Tanggal</th>
                                    <th>Nama Karyawan</th>
                                    <th>Jabatan</th>
                                    <th>Periode</th>
                                    <th>Total Nilai</th>
                                    <th>Klasifikasi</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(item, index) in data2" :key="item.id" class="review-card" @click="lihatDetail(item)">
                                    <td class="text-center">@{{ index + 1 }}</td>
                                    <td>@{{ item.created_at }}</td>
                                    <td>
                                        <strong>@{{ item.karyawan[0]?.nama }}</strong><br>
                                        <small class="text-muted">@{{ item.karyawan[0]?.pekerjaan }}</small>
                                    </td>
                                    <td>@{{ item.karyawan[0]?.jabatan }}</td>
                                    <td>@{{ item.periode[0].nama_periode }}</td>
                                    <td class="text-center font-weight-bold">@{{ item.total_nilai }}</td>
                                    <td class="text-center">
                                        <span :class="'badge badge-' + getKlasifikasiClass(item.klasifikasi)">
                                            @{{ item.klasifikasi }}
                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <button @click.stop="lihatDetail(item)" class="btn btn-sm btn-info mr-1">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        {{-- <button @click.stop="cetakPenilaian(item.id)" class="btn btn-sm btn-secondary">
                                            <i class="fas fa-print"></i>
                                        </button> --}}
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div v-if="data2.length == 0" class="text-center py-5">
                        <i class="fas fa-clipboard-list fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">Belum ada penilaian yang diberikan</h5>
                        <p class="text-muted">Penilaian yang Anda berikan akan muncul di sini</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
