@php
    use app\Fungsi;
@endphp
@extends('Layout.html')
@section('js')
    <script>
        const {
            createApp
        } = Vue

        app = createApp({
            data() {
                data = dataAwal();
                data.baseURL = 'Karyawan';
                data.atasanList = [];
                data.filterStatus = '';
                data.filterRole = '';
                data.filterPekerjaan = '';
                return data;
            },
            computed: {
                ...computedAwal,
                filteredData() {
                    let result = this.data2;
                    if (this.filterStatus) {
                        result = result.filter(i => i.status === this.filterStatus);
                    }
                    if (this.filterRole) {
                        result = result.filter(i => i.role === this.filterRole);
                    }
                    if (this.filterPekerjaan) {
                        result = result.filter(i => i.pekerjaan === this.filterPekerjaan);
                    }
                        

                    return result;
                }
            },
            mounted() {
                this.GetData();
                this.loadAtasanList();
            },
            beforeUpdated() {},
            updated() {},
            methods: {
                ...methodAwal,
                canManage() {
                    return '{{ $Session["admin"]->role ?? "" }}' === 'admin';
                },
                loadAtasanList() {
                    this.apiGet('Karyawan', {
                        role: 'atasan,admin,pimpinan'
                    }).then(res => {
                        this.atasanList = res.data.data.data || [];
                    });
                },
                formatTanggal(tanggal) {
                    if (!tanggal) return '-';
                    const date = new Date(tanggal);
                    return date.toLocaleDateString('id-ID', { day: '2-digit', month: 'short', year: 'numeric' });
                },
                getStatusClass(status) {
                    const mapping = {
                        'aktif': 'success',
                        'nonaktif': 'secondary',
                        'cuti': 'warning',
                        'resign': 'danger'
                    };
                    return mapping[status] || 'secondary';
                },
                getStatusLabel(status) {
                    const mapping = {
                        'aktif': 'Aktif',
                        'nonaktif': 'Non-Aktif',
                        'cuti': 'Cuti',
                        'resign': 'Resign'
                    };
                    return mapping[status] || status;
                },
                getRoleClass(role) {
                    const mapping = {
                        'admin': 'primary',
                        'pimpinan': 'dark',
                        'atasan': 'info',
                        'karyawan': 'secondary'
                    };
                    return mapping[role] || 'secondary';
                },
                getRoleLabel(role) {
                    const mapping = {
                        'admin': 'Admin',
                        'pimpinan': 'Pimpinan',
                        'atasan': 'Atasan',
                        'karyawan': 'Karyawan'
                    };
                    return mapping[role] || role;
                },
                getPekerjaanClass(pekerjaan) {
                    const mapping = {
                        'tetap': 'success',
                        'kontrak': 'warning',
                        'magang': 'info',
                        'outsource': 'secondary'
                    };
                    return mapping[pekerjaan] || 'secondary';
                },
                getPekerjaanLabel(pekerjaan) {
                    const mapping = {
                        'tetap': 'Tetap',
                        'kontrak': 'Kontrak',
                        'magang': 'Magang',
                        'outsource': 'Outsource'
                    };
                    return mapping[pekerjaan] || pekerjaan;
                },
                resetFilter() {
                    this.filterStatus = '';
                    this.filterRole = '';
                    this.filterPekerjaan = '';
                },
                lihatRelasi(karyawanId) {
                    window.location.href = 'RelasiAtasan?karyawan_id=' + karyawanId;
                }
            }
        }).mount('#app')
    </script>
@endsection
@section('css')
    <style>
        .slide-fade-enter-active {
            transition: all 0.3s ease-out;
        }

        .slide-fade-leave-active {
            transition: all 0.8s cubic-bezier(1, 0.5, 0.8, 1);
        }

        .slide-fade-enter-from,
        .slide-fade-leave-to {
            transform: translateX(20px);
            opacity: 0;
        }

        .table-bordered td,
        .table-bordered th {
            color: black !important;
            border: 1px solid #000000 !important;
            padding-top: 5px !important;
            padding-bottom: 5px !important;
            padding-left: 8px !important;
            padding-right: 8px !important;
        }

        .filter-card {
            background-color: #f8f9fc;
            border-left: 4px solid #4e73df;
        }
    </style>
@endsection
@section('modal')
    {{-- Modal Atur Atasan --}}
    <div class="modal fade" id="modalAtasan" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title"><i class="fas fa-sitemap"></i> Atur Relasi Atasan</h5>
                    <button type="button" class="close text-white" data-dismiss="modal">
                        <span>&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label class="font-weight-bold">Pilih Atasan</label>
                        <select class="form-control" id="selectAtasan">
                            <option value="">-- Pilih Atasan --</option>
                            <option v-for="atasan in atasanList" :key="atasan.id" :value="atasan.id">
                                @{{ atasan.nama }} - @{{ atasan.jabatan }}
                            </option>
                        </select>
                        <small class="text-muted">
                            Atasan akan dapat menilai kinerja karyawan ini
                        </small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                    <button type="button" class="btn btn-info">
                        <i class="fas fa-save"></i> Simpan
                    </button>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('isi')
    <div class="row" id="app">
        {{-- Info Card --}}
        <div class="col-12 mb-3">
            <div class="alert alert-info">
                <i class="fas fa-info-circle"></i> 
                <strong>Data Karyawan</strong> - Kelola data karyawan yang akan dinilai kinerjanya. 
                Pastikan data jabatan, status, dan role sudah diisi dengan benar.
            </div>
        </div>

        {{-- Statistik Cards --}}
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Karyawan</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800">@{{ data2.length }}</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-users fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Karyawan Aktif</div>
                            <div v-if="data2" class="h5 mb-0 font-weight-bold text-gray-800">
                                @{{ data2.filter(i => i.status === 'aktif').length }}
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-user-check fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Karyawan Tetap</div>
                            <div v-if="data2" class="h5 mb-0 font-weight-bold text-gray-800">
                                @{{ data2.filter(i => i.pekerjaan === 'tetap').length }}
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-id-badge fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Karyawan Kontrak</div>
                            <div v-if="data2" class="h5 mb-0 font-weight-bold text-gray-800">
                                @{{ data2.filter(i => i.pekerjaan === 'kontrak').length }}
                            </div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-file-contract fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- Filter Card --}}
        <div class="col-12 mb-3">
            <div class="card filter-card shadow-sm">
                <div class="card-body py-2">
                    <div class="row align-items-center">
                        <div class="col-md-3 mb-2 mb-md-0">
                            <label class="small font-weight-bold mb-1">Filter Status</label>
                            <select v-model="filterStatus" class="form-control form-control-sm">
                                <option value="">Semua Status</option>
                                <option value="aktif">Aktif</option>
                                <option value="nonaktif">Non-Aktif</option>
                                <option value="cuti">Cuti</option>
                                <option value="resign">Resign</option>
                            </select>
                        </div>
                        <div class="col-md-3 mb-2 mb-md-0">
                            <label class="small font-weight-bold mb-1">Filter Role</label>
                            <select v-model="filterRole" class="form-control form-control-sm">
                                <option value="">Semua Role</option>
                                <option value="admin">Admin</option>
                                <option value="pimpinan">Pimpinan</option>
                                <option value="atasan">Atasan</option>
                                <option value="karyawan">Karyawan</option>
                            </select>
                        </div>
                        <div class="col-md-3 mb-2 mb-md-0">
                            <label class="small font-weight-bold mb-1">Filter Pekerjaan</label>
                            <select v-model="filterPekerjaan" class="form-control form-control-sm">
                                <option value="">Semua Jenis</option>
                                <option value="tetap">Tetap</option>
                                <option value="kontrak">Kontrak</option>
                                <option value="magang">Magang</option>
                                <option value="outsource">Outsource</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="small font-weight-bold mb-1">&nbsp;</label>
                            <button @click="resetFilter" class="btn btn-sm btn-secondary btn-block">
                                <i class="fas fa-undo"></i> Reset Filter
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        @component('Pages.Form')
            @slot('tambahan')
                {{-- Field: Pekerjaan --}}
                <template v-else-if="inArray(data.name,['pekerjaan'])">
                    <select class="form-control" :name="'input[' + data.name + ']'" :id="data.name + '1'">
                        <option value="">-- Pilih Jenis Pekerjaan --</option>
                        <option value="tetap" :selected="data.val == 'tetap'">Karyawan Tetap</option>
                        <option value="kontrak" :selected="data.val == 'kontrak'">Karyawan Kontrak (PKWT)</option>
                        <option value="magang" :selected="data.val == 'magang'">Magang (Internship)</option>
                        <option value="outsource" :selected="data.val == 'outsource'">Outsource (Pihak Ketiga)</option>
                    </select>
                </template>
                {{-- Field: Status --}}
                <template v-else-if="inArray(data.name,['status'])">
                    <select class="form-control" :name="'input[' + data.name + ']'" :id="data.name + '1'">
                        <option value="">-- Pilih Status --</option>
                        <option value="aktif" :selected="data.val == 'aktif'">Aktif</option>
                        <option value="nonaktif" :selected="data.val == 'nonaktif'">Non-Aktif</option>
                        <option value="cuti" :selected="data.val == 'cuti'">Cuti</option>
                        <option value="resign" :selected="data.val == 'resign'">Resign</option>
                    </select>
                </template>
                {{-- Field: Role --}}
                <template v-else-if="inArray(data.name,['role'])">
                    <select class="form-control" :name="'input[' + data.name + ']'" :id="data.name + '1'">
                        <option value="">-- Pilih Role --</option>
                        <option value="admin" :selected="data.val == 'admin'">Admin (Kelola Data)</option>
                        <option value="pimpinan" :selected="data.val == 'pimpinan'">Pimpinan (Lihat Semua Tanpa Aksi)</option>
                        <option value="atasan" :selected="data.val == 'atasan'">Atasan (Nilai Bawahan)</option>
                        <option value="karyawan" :selected="data.val == 'karyawan'">Karyawan (Lihat Hasil Sendiri)</option>
                    </select>
                </template>
                {{-- Field: Tanggal Bergabung --}}
                <template v-else-if="inArray(data.name,['tanggal_bergabung'])">
                    <input type="date" class="form-control" :name="'input[' + data.name + ']'" 
                        :id="data.name + '1'" :value="data.val">
                </template>
                {{-- Field: Password --}}
                <template v-else-if="inArray(data.name,['password'])">
                    <input type="password" class="form-control" :name="'input[' + data.name + ']'" 
                        :id="data.name + '1'" :value="data.val" placeholder="Kosongkan jika tidak ingin mengubah password">
                    <small class="text-muted">Password akan dienkripsi secara otomatis</small>
                </template>
            @endslot
        @endcomponent
        @component('Pages.Filter')
        @endcomponent

        {{-- Data Table --}}
        <div class="col-lg-12 col-md-12">
            <div class="card o-hidden border-bottom-dark shadow">
                <div class="card-header align-items-center justify-content-between d-flex py-3">
                    <span>
                        <h6 class="m-0 font-weight-bold text-dark">
                            <i class="fas fa-users"></i> Data Karyawan
                            <span class="badge badge-primary ml-2">@{{ filteredData.length }}</span>
                        </h6>
                    </span>
                    <span class="d-flex flex-wrap justify-content-end">
                        <a v-if="canManage()" @click="setAwal" class="btn mr-1 mb-1 btn-sm btn-primary">
                            <i class="fa fa-plus"></i> Tambah
                        </a>
                        <a href="Karyawan-Cetak" target="_blank" class="btn mr-1 mb-1 btn-sm btn-success">
                            <i class="fa fa-print"></i> Cetak
                        </a>
                        <a href="javascript:;" @click="GetData()" class="btn mr-1 mb-1 btn-sm btn-secondary">
                            <i class="fa fa-sync"></i> Refresh
                        </a>
                    </span>
                </div>
                <div class="table-responsive">
                    <table class="table text-nowrap table-striped w-100">
                        <thead class="text-center">
                            <tr>
                                <th>No.</th>
                                <th>Nama</th>
                                <th>Jabatan</th>
                                <th>Jenis Pekerjaan</th>
                                <th>Tgl Bergabung</th>
                                <th>Status</th>
                                <th>Role</th>
                                <th>Username</th>
                                <th>Atasan</th>
                                <th v-if="canManage()">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(i, index) in filteredData" :key="i.id">
                                <td class="text-center">@{{ index + 1 }}</td>
                                <td>
                                    <strong>@{{ i.nama }}</strong>
                                </td>
                                <td>@{{ i.jabatan || '-' }}</td>
                                <td class="text-center">
                                    <span :class="'badge badge-' + getPekerjaanClass(i.pekerjaan)">
                                        @{{ getPekerjaanLabel(i.pekerjaan) }}
                                    </span>
                                </td>
                                <td class="text-center">@{{ formatTanggal(i.tanggal_bergabung) }}</td>
                                <td class="text-center">
                                    <span :class="'badge badge-' + getStatusClass(i.status)">
                                        @{{ getStatusLabel(i.status) }}
                                    </span>
                                </td>
                                <td class="text-center">
                                    <span :class="'badge badge-' + getRoleClass(i.role)">
                                        @{{ getRoleLabel(i.role) }}
                                    </span>
                                </td>
                                <td>@{{ i.username || '-' }}</td>
                                <td>
                                    <span v-if="i.nama_atasan">@{{ i.nama_atasan }}</span>
                                    <span v-else class="text-muted">-</span>
                                </td>
                                <td v-if="canManage()" class="text-center">
                                    <div class="btn-group btn-group-sm">
                                        <button @click="EditData(index)" class="btn btn-warning" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button @click="lihatRelasi(i.id)" class="btn btn-info" title="Atur Atasan">
                                            <i class="fas fa-sitemap"></i>
                                        </button>
                                        <button @click="HapusData(index)" class="btn btn-danger" title="Hapus">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div v-if="filteredData.length == 0" class="text-center py-4">
                    <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                    <h6 class="text-muted">Tidak ada data karyawan</h6>
                </div>
            </div>
        </div>
    </div>
@endsection
