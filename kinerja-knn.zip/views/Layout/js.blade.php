<!--   Core JS Files   -->
<script src="assets/mine/jquery-3.5.1.min.js"></script>
<!-- Bootstrap core JavaScript-->
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="assets/vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="assets/js/sb-admin-2.min.js"></script>


<script src="assets/mine/select2.full.min.js"></script>
<script src="assets/mine/datatables.min.js"></script>
<script src="assets/mine/jQuery.print.js"></script>
<script src="assets/mine/pdfobject.min.js"></script>
<script src="assets/mine/summernote-0.8.18-dist/summernote-lite.js"></script>
<script src="assets/mine/moment.min.js"></script>
<script src="assets/mine/id.min.js"></script>
<script src="assets/mine/jquery.inputmask.min.js"></script>
<script src="assets/mine/JsBarcode.all.min.js"></script>

<script src="assets/mine/inputmask.binding.js"></script>
{{-- <script src="assets/mine/mermaid.min.js"></script> --}}
{{-- <script src="assets/mine/Chart.min.js"></script> --}}
<script src="assets/mine/qrcode.min.js"></script>
<script src="assets/mine/html5-qrcode.min.js"></script>

<script src="assets/mine/vue.global.js"></script>
<script src="assets/mine/Toast.min.js"></script>
<script src="assets/mine/axios.min.js"></script>
<script src="assets/mine/collect.min.js"></script>
<script src="assets/mine/lodash.core.js"></script>
<script src="assets/mine/daterangepicker.min.js"></script>
<script src="assets/mine/signature_pad.umd.min.js"></script>
{{-- <script src="assets/mine/d3.v5.min.js"></script> --}}
<script src="assets/mine/c3.min.js"></script>


<!-- Github buttons -->
<!-- Control Center for Material Dashboard: parallax effects, scripts for the example pages etc -->
{{-- <script>
mermaid.initialize({ startOnLoad: true });
</script> --}}


<script type="text/javascript">
    var aneh;

    const token = localStorage.getItem('jwt');; // token JWT yang telah disimpan

    const axiosInstance = axios.create({
        baseURL: '{{ $GLOBALS['baseURL'] }}',
        headers: {
            'Content-Type': 'multipart/form-data',
            'Authorization': `Bearer ${token}`
        }
    });

    var datetime = null,
        date = null;

    var update = function() {
        date = moment(new Date()).format('dddd, Do MMMM YYYY, HH:mm:ss a');
        // datetime.attr("placeholder", date.format('dddd, Do MMMM YYYY, HH:mm:ss a'));;
        // datetime.val(date.format('dddd, Do MMMM YYYY, HH:mm:ss a'));;
        datetime.html(date);;
    };

    function inArray(needle, haystack) {
        for (var i = 0; i < haystack.length; i++) {
            if (haystack[i] === needle) {
                return true;
            }
        }
        return false;
    }



    function uang(value) {
        let val = (value / 1).toFixed(0).replace('.', ',')
        return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".")
    }


    $(document).ready(function() {
        // $('[data-toggle="popover"]').popover();
        // $('[data-inputmask]').inputmask();
        //var collapseElementList = [].slice.call();
        //new bootstrap.Collapse(document.querySelectorAll('.collapse'));
        datetime = $('#datetime')
        update();
        setInterval(update, 1000);





        AktifDataTable2('.tb2');
        AktifDataTable('.tb');
        AktifDataTable3('.tb3');


        inisiasiAwal();




    });
</script>
<script type="text/javascript">
    function removeCurrencyFormat(value) {
        // Menghapus karakter selain digit, titik, atau koma
        let formattedValue = value.replace(/[^0-9.,]/g, '');

        // Menghapus koma jika ada
        formattedValue = formattedValue.replace(/,/g, '');

        // Menghapus dua digit desimal di akhir jika ada
        if (formattedValue.includes('.')) {
            formattedValue = formattedValue.replace(/^\./, '');
            formattedValue = formattedValue.replace(/0+$/, '');
            formattedValue = formattedValue.replace(/\.$/, '');
        }

        return formattedValue;
    }

    function updateCustomFileLabel(event, labelId) {

        const input = event.target;
        const label = document.getElementById(labelId);
        console.log(input, label);

        if (input.files.length > 0) {
            label.textContent = input.files[0].name;
        } else {
            label.textContent = 'Choose file...';
        }
    }

    function BikinTtd(id) {
        const canvas = document.querySelector(id);
        const signaturePad = new SignaturePad(canvas, {
            penColor: "#2a0ad3"
        });
        return signaturePad;
    }

    function inisiasiAwal() {
        let val = $('input[type="daterange"]').val();

        let start = null;
        let end = null;

        if (val) {
            let dates = val.split(' - ');
            start = moment(dates[0], 'DD/MM/YYYY');
            end = moment(dates[1], 'DD/MM/YYYY');
        } else {
            start = moment().startOf('month');
            end = moment().endOf('month');
        }
        $(".input-mask").inputmask();

        $('input[type="daterange"]').daterangepicker({
            autoUpdateInput: false,
            startDate: start,
            endDate: end,
            locale: {
                cancelLabel: 'Clear'
            }
        });
        $('.summernote').summernote();

        $('input[type="daterange"]').on('apply.daterangepicker', function(ev, picker) {
            $(this).val(picker.startDate.format('DD/MM/YYYY') + ' - ' + picker.endDate.format('DD/MM/YYYY'));
        });

        $('input[type="daterange"]').on('cancel.daterangepicker', function(ev, picker) {
            $(this).val('');
        });

        $('[data-toggle="tooltip"]').tooltip();
        $('.select').select2({
            theme: "bootstrap4",

        });

    }

    function AktifDataTable2(id) {

        return $(id).DataTable({

            responsive: {

                details: {

                    renderer: function(api, rowIdx, columns) {

                        var data = $.map(columns, function(col, i) {

                            return col.hidden ?

                                '<li  class="list-group-item w-100" data-dtr-index="1" data-dt-row="' +
                                col.rowIndex + '" data-dt-column="' + col.columnIndex +
                                '">' +

                                '<div class="d-flex justify-content-between w-100" >' +



                                '<span class="dtr-title ">' + col.title + ':' + '</span> ' +

                                '<span class="dtr-data  text-sm font-weight-bold mb-0 text-break text-wrap">' +
                                col.data + '</span>' +

                                '</li></div>' :

                                '';

                        }).join('');



                        return data ?

                            $('<ul style="display:block;" class="list-group" />').append(data) :

                            false;

                    }

                }

            },
            "dom": '<"p-2 d-flex justify-content-between" fl>t<"card-body d-flex justify-content-between w-100" i p>',


            "lengthMenu": [

                [10, 20, -1],

                [10, 20, "All"]

            ],

            "language": {

                "paginate": {

                    "previous": "<",

                    "next": ">",

                },

                search: "Cari",



            }

        });

    }

    function AktifDataTable(id) {
        return $(id).DataTable({

            responsive: {

                details: {

                    display: $.fn.dataTable.Responsive.display.childRowImmediate,

                    type: 'column',

                    renderer: function(api, rowIdx, columns) {

                        var data = $.map(columns, function(col, i) {

                            return col.hidden ?

                                '<li  class="list-group-item w-100" data-dtr-index="1" data-dt-row="' +
                                col.rowIndex + '" data-dt-column="' + col.columnIndex +
                                '">' +

                                '<div class="d-flex justify-content-between" >' +



                                '<span class="dtr-title">' + col.title + ':' + '</span> ' +

                                '<span class="dtr-data text-right text-break text-wrap">' +
                                col.data + '</span>' +

                                '</li></div>' :

                                '';

                        }).join('');



                        return data ?

                            $('<ul style="display:block;" class="list-group" />').append(data) :

                            false;

                    }

                }

            },

            "dom": '<"p-2 d-flex justify-content-between" f>t<"card-body d-flex justify-content-end" p>',

            "lengthMenu": [

                [10, 20, -1],

                [10, 20, "All"]

            ],

            "language": {

                "paginate": {

                    "previous": "<",

                    "next": ">",

                },

                search: "Cari",



            }

        });
    }

    function numberFormat(number, decimals = 2, decimalSeparator = '.', thousandsSeparator = ',') {
        number = parseFloat(number);

        if (isNaN(number)) {
            return '';
        }

        let fixedNumber = number.toFixed(decimals);
        let parts = fixedNumber.split('.');
        let integerPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandsSeparator);
        let formattedNumber = integerPart;

        if (decimals > 0) {
            let decimalPart = parts[1] || '';
            formattedNumber += decimalSeparator + decimalPart.padEnd(decimals, '0');
        }

        return formattedNumber;
    }

    function AktifDataTable3(id) {
        return $(id).DataTable({



            "dom": '<"p-2 d-flex justify-content-between" f l>t<"card-body d-flex justify-content-start" p>',

            "lengthMenu": [

                [10, 20, -1],

                [10, 20, "All"]

            ],

            "language": {

                "paginate": {

                    "previous": "<",

                    "next": ">",

                },

                search: "Cari",



            }

        });
    }

    function previewImage() {

        var oFReader = new FileReader();

        oFReader.readAsDataURL(document.getElementById("image-source").files[0]);

        // $('#kucing').html(document.getElementById("image-source").files[0].name);


        oFReader.onload = function(oFREvent) {

            document.getElementById("image-preview").src = oFREvent.target.result;

        };


    };

    function modalFoto(foto) {
        document.getElementById("modal-foto2").src = foto;

    };

    function previewImage2(id, id2 = null, id3) {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById(id).files[0]);
        if (id3 != null) {
            $('#' + id3).html(document.getElementById(id).files[0].name);

        }
        if (id2 != null) {

            oFReader.onload = function(oFREvent) {
                document.getElementById(id2).src = oFREvent.target.result;
            };
        }
    };



    function onlyNumberKey(evt) {



        // Only ASCII charactar in that range allowed

        var ASCIICode = (evt.which) ? evt.which : evt.keyCode

        if (ASCIICode > 31 && (ASCIICode < 48 || ASCIICode > 57))

            return false;

        return true;

    }
    $(document).ready(function() {
        $("#direct-hire").on("change", function() {
            let maskPattern = ($(this).val() === "PT KPI") ? "99999999" : "999999";

            // Terapkan inputmask ke #nomorPekerja1
            $("#nomorPekerja1").inputmask(maskPattern);
        });
        let maskPattern = ($('#direct-hire').val() === "PT KPI") ? "99999999" : "999999";

        // Terapkan mask default saat halaman dimuat
        $("#nomorPekerja1").inputmask(maskPattern);
    });
</script>

<script>
    const dataAwal = () => {
        return {
            terpilih: false,
            key: '',
            gambar: 'upload/no-img-placeholder.png',
            index: '',
            method: 'post',
            edit: false,
            data: '',
            fields: '',
            filter: '',
            lastQuery: '',
            tambahan: [],
            kecualiField: null,
            request: {
                'q': null,
                'SortBy': 'tanggal',
                'SortWith': 'DESC',
                'limit': 100
            },
            proses: false,
            prosesFilter: false,
            form: false,
            idTable: '#idTable',
            primary: "",
            baseURL: "Users",
            datatable: null
        }
    }

    const computedAwal = {
        data2() {
            if (this.data) {
                return this.data.all?.() ?? this.data;
            }
            return this.data;
        },
        countFields() {
            if (this.fields) {
                return this.fields.count();
            }
            return 0;
        },

        fields2() {
            let field = this.kecualiField;

            if (this.fields) {
                let r = this.fields;

                if (field) {
                    r = r.whereNotIn('name', field);
                }

                return r.chunk(2).all();
            }

            return this.fields;
        }
    };
    const methodAwal = {
        formatRupiah(value) {
            return uang(value);
        },
        LihatGambar(value) {
            if (value) {
                this.gambar = 'upload/' + value;
            } else {
                this.gambar = 'upload/no-img-placeholder.png';
            }
            if (this.gambar.endsWith('.pdf')) {
                setTimeout(() => {
                    PDFObject.embed(this.gambar, "#example1");
                }, 100);

            } else {
                $('#example1').html(
                    `<img src="` + this.gambar + `" alt="Gambar" class="img-fluid" />`
                );
            }
            $('#modal-gambar').modal('show');
        },
        setAwal() {
            this.form = true;
            this.edit = false;
            $('#form-input').trigger('reset');
            this.fields = this.fields.transform((item, key) => {
                if (Array.isArray(item.val)) {
                    item.val = [];
                } else {
                    item.val = "";
                }
                return item;
            });
            setTimeout(function() {
                var target = $('#atas');
                if (target.length) {
                    $('html, body').stop().animate({
                        scrollTop: target.offset().top
                    }, 1000);
                }
            }, 100);
        },
        onAfterEnter() {
            $('.select').select2({
                theme: "bootstrap4",

            });
            if ($('.select-status').length) {
                $('.select-status').select2({
                    theme: "bootstrap4",
                    tags: true,

                });
            }
            if ($('.select-device').length) {
                $('.select-device').select2({
                    theme: "bootstrap4",
                    tags: true,

                });
            }
            $('.summernote').summernote({
                height: 350
            });
            $('.summernote').css('display', 'block');
            this.tambahan.select?.forEach(element => {
                $('#' + element + '1').change((e) => {
                    this.fields = this.fields.transform((item, key) => {
                        if (item.name == element) {
                            console.log(this.baseURL, element);
                            if (this.baseURL == 'Service' && element == 'transaksi_id') {
                                item.val[0] = e.target.value;

                            } else {
                                item.val = e.target.value;

                            }
                        }
                        return item;
                    });
                });
            });

            // $('.summernote').css('height', '1%');


        },
        numberFormat(number, decimals = 0, decimalSeparator = ',', thousandsSeparator = '.') {
            return numberFormat(number, decimals, decimalSeparator, thousandsSeparator)
        },
        normalizeQueryParams(params = {}) {
            const searchParams = new URLSearchParams();
            Object.entries(params || {}).forEach(([key, value]) => {
                if (value === null || value === undefined || value === '') {
                    return;
                }
                if (Array.isArray(value)) {
                    value.forEach(item => searchParams.append(key, item));
                    return;
                }
                searchParams.append(key, value);
            });
            const queryString = searchParams.toString();
            return queryString ? '?' + queryString : '';
        },
        buildApiUrl(target = null, params = {}) {
            const resource = target || this.baseURL;
            return `/${resource}-Api${this.normalizeQueryParams(params)}`;
        },
        buildCrudUrl(target = null, params = {}) {
            const resource = target || this.baseURL;
            return `/${resource}-CRUD${this.normalizeQueryParams(params)}`;
        },
        apiGet(target = null, params = {}) {
            return axiosInstance.get(this.buildApiUrl(target, params));
        },
        hapusDatatable() {
            if (this.datatable != null) {
                this.datatable.destroy();
                this.datatable = null;
            }
        },
        inisiasiLagi() {

            setTimeout(() => {

                if (this.idTable) {

                    this.datatable = AktifDataTable2(this.idTable);
                }


                inisiasiAwal();
            }, 100);
        },
        inArray(needle, haystack) {
            return inArray(needle, haystack);
        },
        setPDF(pdf) {
            PDFObject.embed(pdf, "#example1");
        },
        onFilter() {
            this.prosesFilter = true;
            const form = document.querySelector('#form-filter');
            const formData = new FormData(form);
            const urlSearchParams = new URLSearchParams(formData);
            const queryString = urlSearchParams.toString();
            this.lastQuery = queryString;
            this.GetData("?" + queryString);
        },
        afterGetdata() {

        },

        HapusData(index) {
            if (confirm("Apakah Anda yakin?")) {
                this.hapusDatatable();

                const formData = new FormData();
                const key = this.data.get(index)[this.primary];
                axiosInstance.delete(this.buildCrudUrl(null, {
                        key
                    }), {})
                    .then((response) => {
                        data = response.data;
                        this.proses = false;
                        if (data.status) {
                            this.data.forget(index);
                            this.filter = collect(data.data.filter);


                            new Toast({
                                message: data.data.msg,
                                type: 'success'
                            });
                            this.inisiasiLagi();

                        } else {
                            new Toast({
                                message: data.data.msg,
                                type: 'danger'
                            });
                        }

                    }).catch(function(error) {
                        new Toast({
                            message: error,
                            type: 'danger'
                        });
                        console.log(error);
                    });

            }
        },
        GetData(request = '') {
            this.hapusDatatable();
            if (request == '') {
                if (this.lastQuery != '') {
                    request = '?' + this.lastQuery;
                }
            }

            axiosInstance.get(this.buildApiUrl() + request, {

                })
                .then((response) => {
                    data = response.data;
                    // console.log( data);
                    if (data.status) {
                        this.fields = collect(data.data.fields);
                        this.tambahan = data.data.tambahan;
                        this.filter = collect(data.data.filter);
                        this.data = collect(data.data.data);
                        this.primary = data.data.primary;
                        this.request = data.data.request;

                        this.inisiasiLagi();
                        this.afterGetdata();


                    } else {
                        new Toast({
                            message: data.data.msg,
                            type: 'danger'
                        });
                    }

                })
                .catch(function(error) {
                    new Toast({
                        message: error,
                        type: 'danger'
                    });

                });

            this.prosesFilter = false;



        },



        EditData(index) {
            this.index = index;
            const data = this.data.get(index);
            this.key = data[this.primary];
            this.fields = this.fields.transform((item, key) => {
                item.val = data[item.name];
                if (item.name == 'password') {
                    item.val = '';
                }
                return item;
            });

            this.form = true;
            $('.modal').modal('hide');

            this.edit = true;
            this.tambahanEdit(data);
            setTimeout(() => {
                this.onAfterEnter();
                var target = $('#atas');
                if (target.length) {
                    $('html, body').stop().animate({
                        scrollTop: target.offset().top
                    }, 500);
                }
            }, 100);
        },
        tambahanEdit(data) {

        },
        ModalContact(num = '') {

            $('#modal-loading').modal('show');
            axios.get('ModalContact?num=' + num)
                .then(res => {
                    $('#placeholder-modal' + num).html(res.data);
                    setTimeout(() => {
                        $('#modal-loading').modal('hide');

                    }, 500);

                    setTimeout(() => {
                        $('#modal-contact' + num).modal('show');

                    }, 1000);


                })
                .catch(err => {
                    $('#modal-loading').modal('hide');

                    console.log(err);
                });


        },
        ModalContactView(key) {

            $('#modal-loading').modal('show');

            axios.get('ModalContact?key=' + key)
                .then(res => {
                    $('#placeholder-modal').html(res.data);
                    setTimeout(() => {
                        $('#modal-loading').modal('hide');

                    }, 500);

                    setTimeout(() => {
                        $('#modal-contact').modal('show');

                    }, 1000);

                })
                .catch(err => {
                    $('#modal-loading').modal('hide');

                    console.log(err);
                });


        },
        ViewTransaksi(key) {

            $('#modal-loading').modal('show');

            axios.get('ViewTransaksi?key=' + key)
                .then(res => {
                    $('#placeholder-modal').html(res.data);
                    setTimeout(() => {
                        $('#modal-loading').modal('hide');

                    }, 500);

                    setTimeout(() => {
                        $('#modal-contact').modal('show');

                    }, 1000);

                })
                .catch(err => {
                    $('#modal-loading').modal('hide');

                    console.log(err);
                });


        },
        FormTransaksi() {

            $('#modal-loading').modal('show');
            axios.get('ViewTransaksi')
                .then(res => {
                    $('#placeholder-modal').html(res.data);
                    setTimeout(() => {
                        $('#modal-loading').modal('hide');

                    }, 500);

                    setTimeout(() => {
                        $('#modal-contact').modal('show');

                    }, 1000);


                })
                .catch(err => {
                    $('#modal-loading').modal('hide');

                    console.log(err);
                });


        },
        ViewProduk(key) {
            $('#modal-loading').modal('show');

            axios.get('Produk-View?key=' + key)
                .then(res => {
                    $('#placeholder-modal2').html(res.data);
                    setTimeout(() => {
                        $('#modal-loading').modal('hide');

                    }, 500);

                    setTimeout(() => {
                        $('#modal-contact2').modal('show');

                    }, 1000);

                })
                .catch(err => {
                    $('#modal-loading').modal('hide');

                    console.log(err);
                });


        },
        FormDevice(num = '') {
            var target = 'Device-View';
            this.ViewModal(target, num);
        },
        ViewDevice(key, num = '') {
            var target = 'Device-View?key=' + key;
            this.ViewModal(target, num);
        },
        ViewUser(key, num = '') {
            var target = 'Users-View?key=' + key;
            this.ViewModal(target, num);
        },
        FormUser(key, num = '') {
            var target = 'Users-View';
            this.ViewModal(target, num);
        },

        ViewService(key, num = '') {
            var target = 'Service-View?key=' + key;
            this.ViewModal(target, num);
        },

        ViewModal(link, num = '') {
            $('#modal-loading').modal('show');

            axios.get(link)
                .then(res => {
                    $('#placeholder-modal' + num).html(res.data);
                    setTimeout(() => {
                        $('#modal-loading').modal('hide');

                    }, 500);

                    setTimeout(() => {
                        $('#modal-contact' + num).modal('show');

                    }, 1000);

                })
                .catch(err => {
                    $('#modal-loading').modal('hide');

                    console.log(err);
                });

        },

        onSubmit(event) {
            this.hapusDatatable();
            this.proses = true;
            const form = event.target;
            console.log(event);

            // Membuat objek FormData
            const formData = new FormData(form);
            // Mengirim request dengan axios
            let fileInput;
            this.tambahan.files?.forEach(element => {
                fileInput = document.getElementById(element);
                if (fileInput != null) {
                    if (fileInput.files[0] != undefined) {
                        formData.append(`input[${element}]`, fileInput.files[0]);
                    }
                }

            });

            if (formData.get('input[jasa]') === null) {
                formData.append('input[jasa]', 0);
            }


            if (this.edit) {
                formData.append('update', true);

            }
            axiosInstance({
                    method: this.method,
                    url: this.buildCrudUrl(),
                    data: formData
                })
                .then((response) => {
                    data = response.data;
                    this.proses = false;
                    if (data.status) {
                        if (this.edit) {
                            this.form = false;
                            this.edit = false;
                            // var hasil = this.data.get(this.index);
                            // for (let index = 0; index <= this.fields.count(); index++) {
                            //     var fieldnya = this.fields.get(index);
                            //     hasil[fieldnya.name] = data.data.data[fieldnya.name];
                            //     // console.log(fieldnya.name, fieldnya.val);

                            // }

                        } else {
                            this.data.push(data.data.data);

                        }
                        this.filter = collect(data.data.filter);
                        this.setAwal();
                        this.form = false;
                        this.GetData();

                        new Toast({
                            message: data.data.msg,
                            type: 'success'
                        });




                    } else {
                        new Toast({
                            message: data.data.msg,
                            type: 'danger'
                        });
                    }

                })
                .catch(function(error) {
                    new Toast({
                        message: error + "<br>",
                        type: 'danger'
                    });

                });





        }
    }
</script>
