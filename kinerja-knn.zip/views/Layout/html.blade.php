<!DOCTYPE html>
<html lang="en">
@include('Layout.head')
@yield('css')

<body id="page-top" class="bg-1">

    <!-- Page Wrapper -->
    <div id="wrapper" class="bg-1 rounded"
        style="padding-right: 2vw;padding-left: 2vw;padding-top: 3vh;padding-bottom: 3vh; ">

        <!-- Sidebar -->
        @include('Layout.sidebar.Menu')
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" style="overflow-x: hidden;overflow-y: hidden" class="d-flex rounded-right shadow-lg flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <!-- Sidebar Toggle (Topbar) -->
                    <div class="d-flex align-items-center">
                        <button id="sidebarToggleTop" class="btn btn-link  rounded-circle mr-3">
                            <i class="fa fa-bars"></i>
                        </button>
                        <h5 class="py-0 my-0">
                            <i class="fa text-dark <?php echo $data['icon']; ?>"></i>
                            <?php echo $data['judul']; ?>
                        </h5>
                    </div>
                    <!-- Topbar Search -->
                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow ml-0">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="btn btn-outline-dark d-none d-lg-block " id="datetime">Selamat Datang,
                                    <strong>Pengunjung</strong></span>
                            </a>
                            <!-- Dropdown - User Information -->
                        </li>

                        <div class="topbar-divider d-none d-sm-block mr-0">
                        </div>
                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown d-none d-lg-block no-arrow ml-0">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php if (isset($Session['admin'])): ?>
                                <div class="d-flex flex-column">
                                    <span class=" d-none d-lg-inline text-gray-600 small">Selamat Datang, </span>
                                    <span class="small text-dark"> <?php echo $Session['admin']->nama; ?></span>
                                </div>


                                <?php else: ?>
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">Selamat Datang,
                                    <strong>Pengunjung</strong></span>
                                <?php endif;?>
                            </a>
                            <!-- Dropdown - User Information -->
                        </li>
                    </ul>
                </nav>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">
                    {{ $GLOBALS['msg']->display() }}
                    @yield('isi')

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; {{ date('Y') }}</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
    <div id="placeholder-modal"></div>



    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

    @yield('modal')
    <div class="modal fade" id="modal-gambar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">

                <div class="modal-body">
                    <div id="example1" style="height: 75vh;: "></div>

                </div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>
    <div id="placeholder-modal2"></div>
    <div class="modal fade" id="modal-loading" data-backdrop="static" tabindex="-1" role="dialog"
        aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm modal-dialog-centered" role="document">
            <div class="modal-content d-flex justify-content-center align-items-center"
                style="height: 150px;border:none;box-shadow:none;background:transparent;">
                <div class="loader"></div>
            </div>
        </div>
    </div>

    @include('Layout.js')

    @yield('js')


</body>

</html>
