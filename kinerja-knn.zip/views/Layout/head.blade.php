<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Sistem Penilaian Kinerja Karyawan - Employee Performance Evaluation System">
    <meta name="author" content="SPKK">
    <link rel="icon" href="assets/img/logo.png" />

    <title> {{ $data['judul'] }} | Sistem Penilaian Kinerja Karyawan</title>
    <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="assets/css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/mine/datatables.min.css" />
    <link rel="stylesheet" href="assets/mine/select2.min.css" />
    <link rel="stylesheet" href="assets/mine/select2-bootstrap4.min.css" />
    <link rel="stylesheet" href="assets/mine/Toast.min.css" />
    <link rel="stylesheet" href="assets/mine/daterangepicker.css" />
    <link rel="stylesheet" href="assets/mine/c3.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

    <link rel="stylesheet" href="assets/mine/summernote-0.8.18-dist/summernote-lite.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/highlight.js/11.9.0/styles/default.min.css">

    @yield('css')
    <style type="text/css">
        .bg-1 {
            background: #1a237e;
            /* fallback for old browsers */
            background: -webkit-linear-gradient(to left, #0d47a1, #1a237e);
            /* Chrome 10-25, Safari 5.1-6 */
            background: linear-gradient(to left, #0d47a1, #1a237e);
            /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
        }

        html {
            scroll-behavior: smooth;
        }

        body {
            font-size: .85rem;
        }

        .bg-2 {
            background-color: #01212c;
            background-image: -webkit-linear-gradient(-65.3deg, #373B44 50%, #2172bf 50%);
        }

        th {
            vertical-align: middle !important
        }

        .page-item.active .page-link {
            z-index: 3;
            color: #fff;
            background-color: #4e73df;
            border-color: #4e73df;
        }

        .bg-gradient-primary {
            background: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
        }

        .bg-gradient-info {
            background: linear-gradient(135deg, #36b9cc 0%, #1a8a99 100%);
        }

        .bg-gradient-success {
            background: linear-gradient(135deg, #1cc88a 0%, #13855c 100%);
        }

        .bg-gradient-warning {
            background: linear-gradient(135deg, #f6c23e 0%, #dda20a 100%);
        }

        .bg-gradient-danger {
            background: linear-gradient(135deg, #e74a3b 0%, #be2617 100%);
        }

        .bg-gradient-dark {
            background: linear-gradient(135deg, #5a5c69 0%, #373840 100%);
        }
    </style>
    <style>
        /* HTML: <div class="loader"></div> */
        .loader {
            width: 50px;
            aspect-ratio: 1;
            display: grid;
        }

        .loader::before,
        .loader::after {
            content: "";
            grid-area: 1/1;
            --c: no-repeat radial-gradient(farthest-side, #4e73df 92%, #0000);
            background:
                var(--c) 50% 0,
                var(--c) 50% 100%,
                var(--c) 100% 50%,
                var(--c) 0 50%;
            background-size: 12px 12px;
            animation: l12 1s infinite;
        }

        .loader::before {
            margin: 4px;
            filter: hue-rotate(45deg);
            background-size: 8px 8px;
            animation-timing-function: linear
        }

        @keyframes l12 {
            100% {
                transform: rotate(.5turn)
            }
        }
    </style>
    {{-- <script src="https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit"></script> --}}
</head>
